# General Description of an LLM

**Project:** example agentic AI use of ASD-STE100  
**Document:** B of 3  
**Created:** 2026-10-15 19:04 MDT  

## Preface — relevant original instructions

> Project: "example agentic AI use of ASD-STE100"
>
> Generate 3 downloadable .md files with relevant titles timestamped to the minute for the 3 following subjects.
>
> B. The General Description of an LLM
>
> Include the relevant sections of this prompt in the preface for each document.
>
> Give me downloadable links to these 3 files.

## Scope

This document addresses subject B in the requested three-document set. It is an explanatory technical report, not a claim of certified compliance with ASD-STE100.

## 1. Definition and purpose

A large language model (LLM) is a machine-learning model trained on text or other tokenized data to estimate probabilities for sequences of tokens. Many contemporary LLMs can generate, summarize, translate, classify, and transform text. Some models also process images, sound, and other modalities. "Large" typically describes substantial model capacity and data/training scale; there is no single universal threshold.

## 2. Inputs, tokens, and outputs

Text is encoded into tokens, which may correspond to words, subwords, symbols, or short character sequences. A model receives an input sequence (its *context*) and produces a probability distribution for the next token. Generation repeatedly selects a token, appends it to the context, and estimates the next distribution. The sequence can end with a stop token or an external stopping condition.

A useful abstraction is:

    P(next token | tokens so far, model parameters)

Token prediction is the operational training and inference objective for many generative LLMs; it does not imply that the model maintains a complete, independently verified internal representation of every fact it states.

## 3. Typical architecture

Many modern LLMs use the Transformer architecture. Important components commonly include token embeddings, position-related information, attention mechanisms, feed-forward transformations, normalization layers, and an output projection. Attention permits each token representation to incorporate information from other relevant positions in its permitted context. Model designs differ; some employ mixtures of experts or architectures beyond standard dense Transformers.

A simplified scaled dot-product attention expression is:

    Attention(Q, K, V) = softmax(Q Kᵀ / sqrt(d_k)) V

Here Q, K, and V are query, key, and value representations, and d_k is the key dimensionality. This is a mechanism for information selection, not by itself a guarantee of reasoning accuracy.

## 4. Training and adaptation

**Pretraining** commonly minimizes prediction error on large collections of tokenized examples. **Post-training** can adapt model behavior through supervised examples and human- or machine-derived preference signals. Other mechanisms include fine-tuning, low-rank adaptation, retrieval-augmented generation (RAG), and additional task-specific training. Training changes model parameters; an ordinary conversation usually does not.

An LLM can use a retrieved reference document at inference time, but having access to a source does not guarantee that each output follows it. Source relevance, version selection, retrieval quality, tool outputs, prompt design, and verification all matter.

## 5. LLM versus an agentic AI system

An LLM is primarily a model that transforms input context into an output distribution. An **agentic AI system** combines one or more models with a task loop, explicit goals, tools, memory or state, and checks. A simplified cycle is:

1. Interpret the assigned objective and constraints.
2. Form or update a plan.
3. Choose an action or tool.
4. Observe the result.
5. Evaluate against acceptance criteria.
6. Continue, correct, or stop.

Not all systems execute every stage, and agentic behavior does not establish correctness or autonomy beyond the system's actual permissions.

## 6. Limits and tests

LLMs can produce plausible but incorrect assertions, omit qualifiers, mishandle unusual inputs, or confuse different versions of a technical standard. Evaluation should test task-specific correctness, reproducibility, source provenance, error rates, safety limits, and performance on withheld examples. Tool use can make an agent more capable, but the tool's actual result must be interpreted correctly.

## 7. Relation to ASD-STE100

ASD-STE100 is a controlled-language standard for technical documentation. An LLM can potentially draft or revise material toward its requirements; a reliable agentic workflow should identify the precise issue of the standard, acquire the authorized reference, apply applicable writing rules and dictionary entries, preserve subject-specific terminology correctly, and perform independent compliance checking. A model's claim that a sentence is STE-compliant is not enough.

Cryptographic hashes can identify exact versions of reference files in such a workflow. Hashing the bytes of a document is not equivalent to reading, interpreting, or verifying that document's technical rules.

## References

1. Vaswani et al. (2017), *Attention Is All You Need*: https://arxiv.org/abs/1706.03762
2. ASD-STE100 official FAQ: https://www.asd-ste100.org/STE_faq.html
3. ASD-STE100 official standard information: https://www.asd-ste100.org/
