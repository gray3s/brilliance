# AIH v5

AIH v5 is the final local-first AIChess benchmark line.

It adds tournament-format and ranking-metric support while keeping the default
run small enough to complete quickly on a normal local laptop. The current
local-agent set is sufficient for a basic v5 benchmark build; larger
open-source/local rosters can be added later as local support improves.

## Primary Files

- `aih_v5.sh` - v5 wrapper/launcher
- `bin/aih_v5` - v5 binary launcher for `aih_v5.sh`
- `AIH_V5_PROJECT_GOALS_20260810.md` - v5 goals
- `AIH_V5_PROJECT_DEVELOPMENT_PLAN_20260810.md` - v5 development plan
- `RUN_AIH_V5_BINARY_INSTRUCTIONS_20260810.md` - run instructions

## Tournament Formats

- Ladder: `./aih_v5.sh --ladder ...`
- Round-robin: `./aih_v5.sh --round-robin ...`
- Round-robin then ladder: `./aih_v5.sh --round-robin-ladder ...`
- Default full v5 test: `./bin/aih_v5`
- Lower-rung round-robin into top-4 ladder override: `./bin/aih_v5 --top4-ladder-rungs ...`

## Ranking Modes

- AIH-only: `--ranking-mode=aih`
- Turn-time-only: `--ranking-mode=turn-time`
- Weighted: `--ranking-mode=weighted`

Weighted mode accepts:

- `--ranking-aih-weight=N`
- `--ranking-turn-time-weight=N`

## Latest Ranking Output

```text
AIH_V5_LATEST_RANKINGS.csv
```

## Caveat

This is currently a wrapper-level v5 fork. Some underlying engine behavior,
binary names, generated paths, and report labels still come from AIH v5 until
the engine is refactored.
