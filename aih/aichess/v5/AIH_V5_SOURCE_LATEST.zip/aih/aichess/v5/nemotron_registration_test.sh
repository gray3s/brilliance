#!/usr/bin/env bash
set -euo pipefail

AIH_V5_DIR="${AIH_V5_DIR:-/home/sag/RPA2/myLLC/AI/brilliance/aih/aichess/v5}"
MODEL="${1:-nemotron-3-nano:4b}"
STAMP="$(date '+%Y%m%d_%H%M%S')"
TMP_ROOT="${TMPDIR:-/tmp}/aih_v5_registration"
TMP_REGISTRY="$TMP_ROOT/local_registry_${STAMP}.csv"

if [[ ! -d "$AIH_V5_DIR" ]]; then
  echo "missing AIH_V5_DIR: $AIH_V5_DIR" >&2
  exit 2
fi

if [[ ! -x "$AIH_V5_DIR/aih_v5.sh" ]]; then
  echo "missing executable: $AIH_V5_DIR/aih_v5.sh" >&2
  exit 2
fi

if ! command -v ollama >/dev/null 2>&1; then
  echo "ollama command not found" >&2
  exit 127
fi

if ! command -v jq >/dev/null 2>&1; then
  echo "jq command not found" >&2
  exit 127
fi

if ! command -v curl >/dev/null 2>&1; then
  echo "curl command not found" >&2
  exit 127
fi

mkdir -p "$AIH_V5_DIR/logs" "$TMP_ROOT"

cat > "$TMP_REGISTRY" <<EOF
candidate,name,model_mode,provider,rank,model,status
1,forced,local,ollama,0,$MODEL,pass
EOF

export AIH_V5_LOCAL_AGENT_REGISTRY="$TMP_REGISTRY"
export AIH_V5_DEFAULT_LOCAL_AGENTS="$MODEL"
export AIH_V5_REGISTRATION_MODE=game
export AIH_V5_REGISTRATION_CANDIDATE_COUNT=1
export AIH_V5_REGISTRATION_ORDER=forward
export AIH_V5_REGISTRATION_GAME_NUM_PREDICT=256
export AIH_V5_REGISTRATION_TIMEOUT_SECONDS=30
export AIH_V5_REGISTRATION_DYNAMIC_TIMEOUT=0
export AIH_V5_REGISTRATION_GAME_SMOKE_PLIES=1
export AIH_V5_REGISTRATION_FINAL_RETRY=0
export AIH_V5_REGISTRATION_KEEP_ALIVE=0s
export AIH_V5_OLLAMA_NUM_THREAD=1
export AIH_V5_OPEN_HTML_REPORT=0
export AIH_V5_TERMINAL_LOG=1

export AIH_V5_REGISTRATION_STATUS_CSV="$AIH_V5_DIR/AIH_V5_REGISTRATION_STATUS_${STAMP}.csv"
export AIH_V5_REGISTRATION_DIAGNOSTIC_LOG="$AIH_V5_DIR/AIH_V5_REGISTRATION_DIAGNOSTICS_${STAMP}.log"
export AIH_V5_TERMINAL_LOG_PATH="$AIH_V5_DIR/logs/aih_v5_registration_${STAMP}.log"

cd "$AIH_V5_DIR"

./aih_v5.sh --registration-only --no-open --registration-forward

echo
echo "model=$MODEL"
echo "temp_registry=$TMP_REGISTRY"
echo "status_csv=$AIH_V5_REGISTRATION_STATUS_CSV"
echo "diagnostic_log=$AIH_V5_REGISTRATION_DIAGNOSTIC_LOG"
echo "terminal_log=$AIH_V5_TERMINAL_LOG_PATH"

if [[ -f "$AIH_V5_REGISTRATION_STATUS_CSV" ]]; then
  echo
  echo "registration_status:"
  cat "$AIH_V5_REGISTRATION_STATUS_CSV"
fi
