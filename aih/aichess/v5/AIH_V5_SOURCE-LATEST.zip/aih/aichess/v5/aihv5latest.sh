#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="/home/sag/RPA2/myLLC/AI/brilliance"
V5_REL="aih/aichess/v5"
V5_DIR="${REPO_ROOT}/${V5_REL}"
BRANCH="main"
REMOTE_BLOB_BASE="https://github.com/gray3s/brilliance/blob/${BRANCH}"
HTMLPREVIEW_BASE="https://htmlpreview.github.io/?${REMOTE_BLOB_BASE}"
COMMIT_MESSAGE="Update AIH v5 public benchmark artifacts"

cd "${V5_DIR}"

echo "[aih-v5-push] refreshing public AIH v5 artifacts"
echo "[aih-v5-push] source: ${V5_DIR}"
echo "[aih-v5-push] publishing root *-LATEST.* files only"

echo "[aih-v5-push] building current AIH v5 binaries"
./tools/build_aih_v5.sh

latest_processors=(
  "./bin/aih_v5_tournament_csv_processor"
  "./bin/aih_v5_registration_csv_processor"
  "./bin/aih_v5_self_play_csv_processor"
  "./bin/aih_v5_project_goals_latest_processor"
  "./bin/aih_v5_implementation_plan_latest_processor"
  "./bin/aih_v5_source_zip_processor"
)

echo "[aih-v5-push] running all AIH v5 latest artifact processor binaries"
for processor in "${latest_processors[@]}"; do
  if [[ ! -x "${processor}" ]]; then
    echo "[aih-v5-push] missing executable latest artifact processor: ${processor}" >&2
    exit 2
  fi
  echo "[aih-v5-push] running ${processor}"
  AIH_V5_OPEN_HTML_REPORT=0 "${processor}"
done

relpaths=(
  "${V5_REL}/AIH_V5_PROJECT_GOALS-LATEST.md"
  "${V5_REL}/AIH_V5_IMPLEMENTATION_PLAN-LATEST.md"
  "${V5_REL}/AIH_V5_CSV_AGGREGATE-LATEST.html"
  "${V5_REL}/AIH_V5_REGISTRATION_AGGREGATE-LATEST.html"
  "${V5_REL}/AIH_V5_DIAGNOSTIC_AGGREGATE-LATEST.html"
  "${V5_REL}/AIH_V5_SOURCE-LATEST.zip"
)

cd "${REPO_ROOT}"

current_branch="$(git branch --show-current)"
if [[ "${current_branch}" != "${BRANCH}" ]]; then
  echo "[aih-v5-push] refusing to push from branch '${current_branch}', expected '${BRANCH}'" >&2
  exit 2
fi

echo
echo "[aih-v5-push] file set:"
for relpath in "${relpaths[@]}"; do
  if [[ ! -r "${relpath}" ]]; then
    echo "[aih-v5-push] missing required file: ${relpath}" >&2
    exit 2
  fi
  echo "  ${relpath}"
done

echo
echo "[aih-v5-push] links after push:"
echo "  Project goals: ${REMOTE_BLOB_BASE}/${V5_REL}/AIH_V5_PROJECT_GOALS-LATEST.md"
echo "  Project implementation plan: ${REMOTE_BLOB_BASE}/${V5_REL}/AIH_V5_IMPLEMENTATION_PLAN-LATEST.md"
echo "  Tournament CSV analyzer: ${HTMLPREVIEW_BASE}/${V5_REL}/AIH_V5_CSV_AGGREGATE-LATEST.html"
echo "  Registration aggregate: ${HTMLPREVIEW_BASE}/${V5_REL}/AIH_V5_REGISTRATION_AGGREGATE-LATEST.html"
echo "  Diagnostic / self-play aggregate: ${HTMLPREVIEW_BASE}/${V5_REL}/AIH_V5_DIAGNOSTIC_AGGREGATE-LATEST.html"
echo "  AIH v5 Code: ${REMOTE_BLOB_BASE}/${V5_REL}/AIH_V5_SOURCE-LATEST.zip"

echo
echo "[aih-v5-push] git status before staging:"
git status --short -- "${relpaths[@]}"

echo
echo "[aih-v5-push] staging exact AIH v5 file set"
git add -- "${relpaths[@]}"

if git diff --cached --quiet -- "${relpaths[@]}"; then
  echo "[aih-v5-push] no staged changes; nothing to commit or push"
  exit 0
fi

echo "[aih-v5-push] committing"
git commit -m "${COMMIT_MESSAGE}" -- "${relpaths[@]}"

echo "[aih-v5-push] fetching origin/${BRANCH}"
git fetch origin "${BRANCH}"

if ! git merge-base --is-ancestor "origin/${BRANCH}" HEAD; then
  echo "[aih-v5-push] merging remote ${BRANCH} before push"
  git merge --no-edit "origin/${BRANCH}"
fi

echo "[aih-v5-push] pushing origin/${BRANCH}"
git push origin "${BRANCH}"

echo
echo "[aih-v5-push] pushed AIH v5 public artifacts"
