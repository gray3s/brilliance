#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

namespace fs = std::filesystem;

static fs::path v5_root(char** argv) {
  fs::path self = argv[0] ? fs::path(argv[0]) : fs::path{};
  fs::path bin = self.has_parent_path() ? fs::absolute(self).parent_path() : fs::current_path();
  return bin.parent_path();
}

static std::string timestamp(const char* fmt) {
  auto now = std::chrono::system_clock::now();
  std::time_t t = std::chrono::system_clock::to_time_t(now);
  std::tm tm{};
  localtime_r(&t, &tm);
  std::ostringstream out;
  out << std::put_time(&tm, fmt);
  return out.str();
}

static bool has_source_extension(const fs::path& path) {
  const std::string name = path.filename().string();
  const std::string ext = path.extension().string();
  return ext == ".c" || ext == ".cc" || ext == ".cpp" || ext == ".h" ||
         ext == ".hh" || ext == ".hpp" || ext == ".pro" || ext == ".pri" ||
         ext == ".sh" || name == "CMakeLists.txt" || name == "Makefile";
}

static bool under_dir(const fs::path& rel, const std::string& dir) {
  for (const auto& part : rel) {
    if (part == dir) return true;
  }
  return false;
}

static bool excluded(const fs::path& rel) {
  static const std::vector<std::string> dirs = {
      ".git", "logs", "data", "runs", "published_results", "qualification_cache",
      "node_modules", "build", ".cache"};
  for (const auto& dir : dirs) {
    if (under_dir(rel, dir)) return true;
  }
  return false;
}

static void copy_if_present(const fs::path& root, const fs::path& stage, const fs::path& src) {
  if (!fs::is_regular_file(src)) return;
  const fs::path rel = fs::relative(src, root);
  const fs::path dst = stage / "aih/aichess/v5" / rel;
  fs::create_directories(dst.parent_path());
  fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
}

static int run_zip(const fs::path& zip_path, const fs::path& stage) {
  pid_t pid = fork();
  if (pid == 0) {
    if (chdir(stage.c_str()) != 0) _exit(127);
    execlp("zip", "zip", "-q", "-r", zip_path.c_str(), "aih", static_cast<char*>(nullptr));
    _exit(127);
  }
  if (pid < 0) return 127;

  int status = 0;
  if (waitpid(pid, &status, 0) < 0) return 127;
  if (WIFEXITED(status)) return WEXITSTATUS(status);
  if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
  return 127;
}

int main(int, char** argv) {
  const fs::path root = v5_root(argv);
  const std::string today = timestamp("%Y%m%d");
  const std::string stamp = timestamp("%Y%m%d_%H%M%S");
  const fs::path dated_zip = root / ("AIH_V5_SOURCE_" + today + ".zip");
  const fs::path latest_zip = root / "AIH_V5_SOURCE-LATEST.zip";
  const fs::path stage = root / (".aih_v5_source_stage_" + stamp);

  try {
    fs::remove_all(stage);
    fs::create_directories(stage / "aih/aichess/v5");

    copy_if_present(root, stage, root / "aih_v5.sh");
    copy_if_present(root, stage, root / "README.md");

    for (const auto& entry : fs::recursive_directory_iterator(root)) {
      if (!entry.is_regular_file()) continue;
      const fs::path rel = fs::relative(entry.path(), root);
      if (excluded(rel) || !has_source_extension(entry.path())) continue;
      copy_if_present(root, stage, entry.path());
    }

    std::vector<std::string> included;
    const fs::path staged_root = stage / "aih/aichess/v5";
    for (const auto& entry : fs::recursive_directory_iterator(staged_root)) {
      if (!entry.is_regular_file()) continue;
      included.push_back(fs::relative(entry.path(), stage).generic_string());
    }
    std::sort(included.begin(), included.end());

    const fs::path manifest = staged_root / "AIH_V5_SOURCE_MANIFEST.txt";
    std::ofstream out(manifest);
    out << "AIH v5 source-only archive\n";
    out << "Generated: " << timestamp("%Y-%m-%d %H:%M:%S") << "\n";
    out << "Source root: " << root << "\n\n";
    out << "Purpose:\n";
    out << "Current AIH v5 C/C++/Qt and supporting source code for public review/recreation.\n\n";
    out << "Explicitly excluded:\n";
    out << "- compiled executables/binaries\n";
    out << "- *.o and other object files\n";
    out << "- raw CSV data\n";
    out << "- JSONL event/run data\n";
    out << "- logs\n";
    out << "- caches\n";
    out << "- generated run output\n\n";
    out << "Included files:\n";
    for (const auto& item : included) out << item << "\n";
    out.close();

    fs::remove(dated_zip);
    fs::remove(latest_zip);
    const int zip_status = run_zip(dated_zip, stage);
    if (zip_status != 0) {
      std::cerr << "zip failed with status " << zip_status << "\n";
      fs::remove_all(stage);
      return zip_status;
    }
    fs::copy_file(dated_zip, latest_zip, fs::copy_options::overwrite_existing);
    fs::remove_all(stage);

    std::cout << "[aih-v5-source-zip] wrote " << dated_zip << "\n";
    std::cout << "[aih-v5-source-zip] wrote " << latest_zip << "\n";
    std::cout << "[aih-v5-source-zip] files: " << included.size() + 1 << "\n";
  } catch (const std::exception& e) {
    std::cerr << "failed to build AIH v5 source zip: " << e.what() << "\n";
    std::error_code ec;
    fs::remove_all(stage, ec);
    return 2;
  }

  return 0;
}
