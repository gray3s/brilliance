#include <filesystem>
#include <iostream>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

namespace fs = std::filesystem;

#ifndef AIH_V5_CSV_PROCESSOR_KIND
#define AIH_V5_CSV_PROCESSOR_KIND "tournament"
#endif

static fs::path binary_dir(char** argv) {
  fs::path self = argv[0] ? fs::path(argv[0]) : fs::path{};
  if (self.has_parent_path()) return fs::absolute(self).parent_path();
  return fs::current_path();
}

static int run_child(const fs::path& exe, const std::vector<std::string>& args) {
  std::vector<std::string> storage;
  storage.push_back(exe.string());
  storage.insert(storage.end(), args.begin(), args.end());

  std::vector<char*> cargs;
  for (auto& s : storage) cargs.push_back(s.data());
  cargs.push_back(nullptr);

  pid_t pid = fork();
  if (pid == 0) {
    execv(exe.c_str(), cargs.data());
    _exit(127);
  }
  if (pid < 0) return 127;

  int status = 0;
  if (waitpid(pid, &status, 0) < 0) return 127;
  if (WIFEXITED(status)) return WEXITSTATUS(status);
  if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
  return 127;
}

static std::vector<std::string> tail_args(int argc, char** argv, int start) {
  std::vector<std::string> out;
  for (int i = start; i < argc; ++i) out.emplace_back(argv[i]);
  return out;
}

static int run_tournament(const fs::path& bin, const std::vector<std::string>& extra) {
  std::vector<std::string> args = {"--csv-all"};
  args.insert(args.end(), extra.begin(), extra.end());
  return run_child(bin / "aih_v5_html_report", args);
}

static int run_repeat_report(const fs::path& bin, const std::vector<std::string>& extra) {
  return run_child(bin / "aih_v5_repeat_html", extra);
}

int main(int argc, char** argv) {
  fs::path bin = binary_dir(argv);
  std::string kind = AIH_V5_CSV_PROCESSOR_KIND;
  std::vector<std::string> extra = tail_args(argc, argv, 1);

  if (kind == "tournament") return run_tournament(bin, extra);
  if (kind == "registration") {
    extra.insert(extra.begin(), "--registration-only");
    return run_repeat_report(bin, extra);
  }
  if (kind == "self-play") {
    extra.insert(extra.begin(), "--self-play-only");
    return run_repeat_report(bin, extra);
  }

  std::cerr << "unknown AIH v5 CSV processor kind: " << kind << "\n";
  return 2;
}
