#include <filesystem>
#include <iostream>
#include <string>

namespace fs = std::filesystem;

#ifndef AIH_V5_MARKDOWN_SOURCE
#define AIH_V5_MARKDOWN_SOURCE "AIH_V5_PROJECT_GOALS.md"
#endif

#ifndef AIH_V5_MARKDOWN_LATEST
#define AIH_V5_MARKDOWN_LATEST "AIH_V5_PROJECT_GOALS-LATEST.md"
#endif

static fs::path v5_root(char** argv) {
  fs::path self = argv[0] ? fs::path(argv[0]) : fs::path{};
  fs::path bin = self.has_parent_path() ? fs::absolute(self).parent_path() : fs::current_path();
  return bin.parent_path();
}

int main(int, char** argv) {
  const fs::path root = v5_root(argv);
  const fs::path source = root / AIH_V5_MARKDOWN_SOURCE;
  const fs::path latest = root / AIH_V5_MARKDOWN_LATEST;

  if (!fs::is_regular_file(source)) {
    std::cerr << "missing AIH v5 markdown source: " << source << "\n";
    return 2;
  }

  std::error_code ec;
  fs::copy_file(source, latest, fs::copy_options::overwrite_existing, ec);
  if (ec) {
    std::cerr << "failed to write " << latest << ": " << ec.message() << "\n";
    return 2;
  }

  std::cout << "[aih-v5-latest-markdown] wrote " << latest << "\n";
  return 0;
}
