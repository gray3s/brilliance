#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT_DIR/tools/script_binary_launcher.cpp"
OUT_DIR="$ROOT_DIR/bin"
CXX="${CXX:-c++}"
CXXFLAGS_DEFAULT="-O2 -std=c++17 -Wall -Wextra"

mkdir -p "$OUT_DIR"
chmod +x "$ROOT_DIR/aih_v5.sh"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DSCRIPT_REL_PATH=\"aih_v5.sh\"" \
  "$SRC" \
  -o "$OUT_DIR/aih_v5"

chmod +x "$OUT_DIR/aih_v5"
printf '%s -> %s\n' "$OUT_DIR/aih_v5" "aih_v5.sh"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "$ROOT_DIR/tools/generate_aih_v5_html_report.cpp" \
  -o "$OUT_DIR/aih_v5_html_report"

chmod +x "$OUT_DIR/aih_v5_html_report"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_html_report" "tools/generate_aih_v5_html_report.cpp"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "$ROOT_DIR/tools/generate_aih_v5_repeat_html.cpp" \
  -o "$OUT_DIR/aih_v5_repeat_html"

chmod +x "$OUT_DIR/aih_v5_repeat_html"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_repeat_html" "tools/generate_aih_v5_repeat_html.cpp"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "$ROOT_DIR/tools/run_aih_v5_repeat.cpp" \
  -o "$OUT_DIR/aih_v5_repeat"

chmod +x "$OUT_DIR/aih_v5_repeat"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_repeat" "tools/run_aih_v5_repeat.cpp"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "$ROOT_DIR/tools/run_aih_v5_single_game.cpp" \
  -o "$OUT_DIR/aih_v5_single_game"

chmod +x "$OUT_DIR/aih_v5_single_game"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_single_game" "tools/run_aih_v5_single_game.cpp"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DAIH_V5_CSV_PROCESSOR_KIND=\"tournament\"" \
  "$ROOT_DIR/tools/aih_v5_csv_processor.cpp" \
  -o "$OUT_DIR/aih_v5_tournament_csv_processor"
chmod +x "$OUT_DIR/aih_v5_tournament_csv_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_tournament_csv_processor" "tools/aih_v5_csv_processor.cpp tournament"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DAIH_V5_CSV_PROCESSOR_KIND=\"registration\"" \
  "$ROOT_DIR/tools/aih_v5_csv_processor.cpp" \
  -o "$OUT_DIR/aih_v5_registration_csv_processor"
chmod +x "$OUT_DIR/aih_v5_registration_csv_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_registration_csv_processor" "tools/aih_v5_csv_processor.cpp registration"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DAIH_V5_CSV_PROCESSOR_KIND=\"self-play\"" \
  "$ROOT_DIR/tools/aih_v5_csv_processor.cpp" \
  -o "$OUT_DIR/aih_v5_self_play_csv_processor"
chmod +x "$OUT_DIR/aih_v5_self_play_csv_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_self_play_csv_processor" "tools/aih_v5_csv_processor.cpp self-play"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DAIH_V5_MARKDOWN_SOURCE=\"AIH_V5_PROJECT_GOALS.md\"" \
  "-DAIH_V5_MARKDOWN_LATEST=\"AIH_V5_PROJECT_GOALS-LATEST.md\"" \
  "$ROOT_DIR/tools/aih_v5_latest_markdown_processor.cpp" \
  -o "$OUT_DIR/aih_v5_project_goals_latest_processor"
chmod +x "$OUT_DIR/aih_v5_project_goals_latest_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_project_goals_latest_processor" "tools/aih_v5_latest_markdown_processor.cpp project-goals"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "-DAIH_V5_MARKDOWN_SOURCE=\"AIH_V5_IMPLEMENTATION_PLAN.md\"" \
  "-DAIH_V5_MARKDOWN_LATEST=\"AIH_V5_IMPLEMENTATION_PLAN-LATEST.md\"" \
  "$ROOT_DIR/tools/aih_v5_latest_markdown_processor.cpp" \
  -o "$OUT_DIR/aih_v5_implementation_plan_latest_processor"
chmod +x "$OUT_DIR/aih_v5_implementation_plan_latest_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_implementation_plan_latest_processor" "tools/aih_v5_latest_markdown_processor.cpp implementation-plan"

"$CXX" ${CXXFLAGS:-$CXXFLAGS_DEFAULT} \
  "$ROOT_DIR/tools/aih_v5_source_zip_processor.cpp" \
  -o "$OUT_DIR/aih_v5_source_zip_processor"
chmod +x "$OUT_DIR/aih_v5_source_zip_processor"
printf '%s -> %s\n' "$OUT_DIR/aih_v5_source_zip_processor" "tools/aih_v5_source_zip_processor.cpp"
