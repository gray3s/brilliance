#!/usr/bin/env bash
set -euo pipefail

# AIH v5 canonical GitHub publication script.
# Updates content behind four permanent public links. No dated publication
# filenames are created or staged by this script.

REPO_ROOT="/home/sag/RPA2/myLLC/AI/brilliance"
V5="$REPO_ROOT/aih/aichess/v5"
LOCAL_SUMMARY_DIR="$HOME/RPA2/gpt/aih/v5"
LOCAL_SUMMARY="$LOCAL_SUMMARY_DIR/AIH_V5_GITHUB_UPDATE_PROJECT_SUMMARY.txt"

GOALS="$V5/AIH_V5_PROJECT_GOALS.md"
PLAN="$V5/AIH_V5_IMPLEMENTATION_PLAN.md"
CSV_HTML="$V5/AIH_V5_CSV_AGGREGATE_LATEST.html"
DATA_CSV_HTML="$V5/data/AIH_V5_CSV_AGGREGATE_LATEST.html"
SOURCE_ZIP="$V5/AIH_V5_SOURCE_LATEST.zip"

REPO_SLUG="gray3s/brilliance"
BRANCH="main"
REMOTE="origin"
GITHUB_BASE="https://github.com/$REPO_SLUG/blob/$BRANCH/aih/aichess/v5"
RAW_BASE="https://raw.githubusercontent.com/$REPO_SLUG/$BRANCH/aih/aichess/v5"
GOALS_URL="$GITHUB_BASE/AIH_V5_PROJECT_GOALS.md"
PLAN_URL="$GITHUB_BASE/AIH_V5_IMPLEMENTATION_PLAN.md"
HTML_URL="https://htmlpreview.github.io/?https://github.com/$REPO_SLUG/blob/$BRANCH/aih/aichess/v5/AIH_V5_CSV_AGGREGATE_LATEST.html"
SOURCE_URL="$GITHUB_BASE/AIH_V5_SOURCE_LATEST.zip"
COMMIT_MESSAGE="Refresh AIH v5 public goals, plan, analysis, and source"

PUB_REL=(
  "aih/aichess/v5/AIH_V5_PROJECT_GOALS.md"
  "aih/aichess/v5/AIH_V5_IMPLEMENTATION_PLAN.md"
  "aih/aichess/v5/AIH_V5_CSV_AGGREGATE_LATEST.html"
  "aih/aichess/v5/AIH_V5_SOURCE_LATEST.zip"
)

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

need() {
  command -v "$1" >/dev/null 2>&1 || fail "required command not found: $1"
}

for cmd in git c++ zip curl sha256sum find sed grep awk sort cmp mktemp; do
  need "$cmd"
done

[[ -d "$REPO_ROOT/.git" ]] || fail "not a git repository: $REPO_ROOT"
[[ -d "$V5" ]] || fail "AIH v5 directory missing: $V5"
[[ -r "$V5/tools/generate_aih_v5_html_report.cpp" ]] || \
  fail "CSV analyzer source missing: $V5/tools/generate_aih_v5_html_report.cpp"

cd "$REPO_ROOT"
actual_root="$(git rev-parse --show-toplevel)"
[[ "$actual_root" == "$REPO_ROOT" ]] || fail "unexpected git root: $actual_root"

actual_branch="$(git branch --show-current)"
[[ "$actual_branch" == "$BRANCH" ]] || fail "expected branch '$BRANCH', found '$actual_branch'"

origin_url="$(git remote get-url "$REMOTE")"
case "$origin_url" in
  https://github.com/gray3s/brilliance.git|git@github.com:gray3s/brilliance.git|ssh://git@github.com/gray3s/brilliance.git)
    ;;
  *) fail "unexpected origin URL: $origin_url" ;;
esac

# Refuse to combine this publication with anything already staged.
if [[ -n "$(git diff --cached --name-only)" ]]; then
  echo "Already-staged files:" >&2
  git diff --cached --name-only >&2
  fail "unstage those files before running this publication script"
fi

echo "Fetching $REMOTE/$BRANCH..."
git fetch "$REMOTE" "$BRANCH"
local_head="$(git rev-parse HEAD)"
remote_head_before="$(git rev-parse "$REMOTE/$BRANCH")"
[[ "$local_head" == "$remote_head_before" ]] || {
  echo "local HEAD : $local_head" >&2
  echo "remote HEAD: $remote_head_before" >&2
  fail "local $BRANCH must exactly match $REMOTE/$BRANCH before publication"
}

TMP_ROOT="$(mktemp -d)"
cleanup() {
  rm -rf "$TMP_ROOT"
}
trap cleanup EXIT

# ---------------------------------------------------------------------------
# 1. Rebuild the current CSV analyzer from source and regenerate the canonical
#    CSV aggregate. The C++ reporter supports --csv-all/--csv-data/--all-csv.
# ---------------------------------------------------------------------------
ANALYZER_BIN="$TMP_ROOT/aih_v5_html_report"
echo "Building CSV analyzer..."
c++ -O2 -std=c++17 -Wall -Wextra \
  "$V5/tools/generate_aih_v5_html_report.cpp" \
  -o "$ANALYZER_BIN"

echo "Regenerating canonical CSV aggregate..."
(
  cd "$V5"
  AIH_V5_OPEN_HTML_REPORT=0 "$ANALYZER_BIN" --csv-all "$CSV_HTML"
)
[[ -s "$CSV_HTML" ]] || fail "CSV analyzer did not create $CSV_HTML"
# The analyzer itself mirrors the canonical file under data/. Keep that local
# mirror current, but it is intentionally NOT staged by this script.
[[ -s "$DATA_CSV_HTML" ]] || cp -f "$CSV_HTML" "$DATA_CSV_HTML"

# Extract current aggregate snapshot values for the documentation. Failure to
# parse a cosmetic metric is nonfatal; the docs will say "current" instead.
html_value() {
  local label="$1"
  sed -n "s@.*${label}<b>\\([^<]*\\)</b>.*@\\1@p" "$CSV_HTML" | head -n1
}
CSV_INCLUDED="$(sed -n 's@.*#csv files inc\.: <code>\([^<]*\)</code>.*@\1@p' "$CSV_HTML" | head -n1 || true)"
RANKING_FILES="$(html_value 'Ranking CSV files' || true)"
REGISTRATION_FILES="$(html_value 'Registration CSV files' || true)"
RANKING_ROWS="$(html_value 'Ranking rows' || true)"
AGENTS_RANKED="$(html_value 'Agents ranked' || true)"
EVENTS_OBSERVED="$(html_value 'Total events observed' || true)"

snapshot_line="Current publication analysis is regenerated from the contents of \`v5/data\` immediately before each GitHub update."
if [[ -n "$CSV_INCLUDED" && -n "$AGENTS_RANKED" && -n "$EVENTS_OBSERVED" ]]; then
  snapshot_line="For this publication run, the CSV processor included ${CSV_INCLUDED} CSV files, ranked ${AGENTS_RANKED} agents, and observed ${EVENTS_OBSERVED} events."
fi

# ---------------------------------------------------------------------------
# 2. Rewrite the two canonical public documentation files. Stable filenames
#    and URLs are preserved; only content changes.
# ---------------------------------------------------------------------------
cat > "$GOALS" <<EOF
# AIH v5 Project Goals and Implementation Target

Date: 2026-08-12

Permanent public artifacts:

- Project goals: ${GOALS_URL}
- Project implementation plan: ${PLAN_URL}
- Current CSV analysis: ${HTML_URL}
- Current source code ZIP: ${SOURCE_URL}

AIH v5 is a local-first agentic-AI benchmark prototype. Its immediate purpose is to compare AI agents with a small, repeatable chess-harness workload while measuring observable AI hallucination/failure behavior, usable responses, timing, and throughput on hardware that a normal user can own and control.

The project is deliberately local-first rather than cloud-dependent. Local Ollama models are the baseline. Cloud/provider paths may be tested as explicit configurations, but a provider that requires an account, token, API key, or working Internet connection is not classified as local AI.

## Primary Goals

- Run a useful benchmark on laptop-class hardware without requiring cloud APIs.
- Register candidate agents before tournament play and exclude candidates that cannot reliably talk to the harness.
- Preserve registration failures and other AIH events in reporting rather than silently dropping them.
- Use bounded chess positions and constrained UCI-move prompts as a repeatable agent test harness.
- Rank agents primarily by measured AIH behavior, with response timing and weighted metrics available as additional ranking information.
- Persist machine-readable run data under \`v5/data\` so results can be recomputed rather than inferred from screenshots or terminal text.
- Generate browser-readable HTML summaries from the saved data.
- Keep the implementation inspectable and reproducible with C++, Qt, shell tooling, and local data files.
- Publish stable public links whose contents can be refreshed without changing the LinkedIn/GitHub URLs.

## Current Runtime Shape

The canonical user entry point is:

\`\`\`bash
./bin/aih_v5
\`\`\`

The current implementation is a binary-fronted local workflow:

- \`aih_v5.sh\` is the main orchestration wrapper.
- \`./bin/aih_v5\` is the binary launcher for that wrapper.
- \`qwen_ollama_chess_qt/main.cpp\` is the current Qt/C++ chess and model-interaction engine source.
- \`tools/generate_aih_v5_html_report.cpp\` is the current C++ HTML/CSV analysis reporter.
- \`tools/generate_aih_v5_repeat_html.cpp\` is the registration-repeat aggregate reporter.
- \`tools/run_aih_v5_repeat.cpp\` and shell helpers support repeat execution and local-stack handling.

The default local backend is Ollama over localhost HTTP. The current code also contains explicit provider/model labeling and controls for reasoning/performance/verbosity configurations. Those settings are benchmark configuration state and must not be confused with model identity.

## Registration and Tournament Model

Registration is a liveness/compatibility filter, not the tournament itself. A passing candidate has demonstrated that it can communicate with the harness within the configured limits. A registration failure or timeout remains evidence and is retained in the data.

Tournament play uses registered agents only. The principal v5 format is top-4 ladder-rungs with a round-robin seeding phase followed by bounded head-to-head placement. Other round-robin and ladder forms remain supported by the wrapper.

The move request is intentionally constrained: the agent is asked for one legal UCI move. Illegal, unparseable, irrelevant, empty, timed-out, and transport-failed responses are observable AIH/failure events. Legal accepted moves are non-AIH/usable events for the benchmark.

## AIH and Ranking Semantics

The current CSV processor uses two event classes per agent:

- AIH events: observable failures such as hallucinated/illegal/unparseable output, irrelevant output, transport failure, timeout, and registration failure where applicable.
- Non-AIH events: usable observed events, principally accepted legal responses and successful registration evidence where represented by the source data.

For the aggregate analysis:

\`AIH% = AIH events / observed events\`

Lower AIH% is better. The current report also exposes CSV-row counts, AIH and non-AIH event counts, average legal-event time, average AIH-event time, weighted performance, and token throughput when the underlying records support those measurements.

${snapshot_line}

## Data and Reporting Contract

Active run data belongs under:

\`\`\`text
aih/aichess/v5/data/
\`\`\`

The current CSV analyzer scans the saved v5 data and combines ranking CSV, registration CSV, and event JSONL evidence when available. It writes the canonical public report:

\`\`\`text
AIH_V5_CSV_AGGREGATE_LATEST.html
\`\`\`

and mirrors the same report locally under:

\`\`\`text
data/AIH_V5_CSV_AGGREGATE_LATEST.html
\`\`\`

The registration-only aggregate is a separate artifact and must not be substituted for the broader CSV aggregate.

## Thought / Reasoning / Verbosity Configuration

The current implementation keeps base provider/model identity separate from controls such as:

- \`AICHESS_REASONING_PERFORMANCE_MODE\`
- \`AICHESS_OPENAI_REASONING_EFFORT\`
- \`AICHESS_VERBOSITY\`
- \`AICHESS_OPENAI_TEXT_VERBOSITY\`

A base model tested under different reasoning or verbosity settings is a different benchmark configuration. Until every report carries those settings as explicit ranking columns, direct comparisons of the same base model under multiple thought modes should remain separated by run/reference configuration rather than being treated as one homogeneous sample.

## Hardware Philosophy

AIH v5 targets modest local hardware first. Better CPU, GPU, RAM, and SSD resources are accelerators, not assumptions built into the meaning of the benchmark. Default concurrency should remain conservative enough that local-model resource contention does not become the dominant measurement.

## Publication Contract

The public AIH v5 state is represented by four permanent files:

1. \`AIH_V5_PROJECT_GOALS.md\`
2. \`AIH_V5_IMPLEMENTATION_PLAN.md\`
3. \`AIH_V5_CSV_AGGREGATE_LATEST.html\`
4. \`AIH_V5_SOURCE_LATEST.zip\`

Their filenames and public links are intentionally stable. Publication updates replace their contents rather than creating new dated public links.

The source ZIP is source-only: current C/C++/Qt code plus supporting shell/build files. It excludes compiled binaries, object files, raw CSV/JSONL datasets, logs, caches, and run-output directories.

## Recreation Target

A recreation is close to the AIH v5 target when it can:

- build or expose \`./bin/aih_v5\`;
- register local candidates with bounded timeouts;
- execute the constrained chess harness over registered agents;
- retain observable failure/AIH evidence;
- persist run data under \`v5/data\`;
- repeat runs without opening a browser tab for every child run;
- regenerate the aggregate CSV/JSONL-derived HTML report from saved data; and
- reproduce the four canonical publication artifacts above.
EOF

cat > "$PLAN" <<EOF
# AIH v5 Implementation Plan

Date: 2026-08-12

This file supplements \`AIH_V5_PROJECT_GOALS.md\`. The goals file defines what AIH v5 is intended to measure and publish; this file describes the current practical implementation and the steps needed to keep the benchmark reproducible.

Permanent public artifacts:

- Project goals: ${GOALS_URL}
- Project implementation plan: ${PLAN_URL}
- Current CSV analysis: ${HTML_URL}
- Current source code ZIP: ${SOURCE_URL}

## 1. Preserve the Current User Entry Point

Keep the normal launch command stable:

\`\`\`bash
./bin/aih_v5
\`\`\`

The binary launcher should continue to hand control to \`aih_v5.sh\`, which owns configuration, registration, repeat-run behavior, tournament selection, reporting, terminal progress, and failure handling.

Do not require a cloud key for the default path. Ollama/localhost remains the local baseline.

## 2. Current Source Components

Maintain these principal source components:

- \`aih_v5.sh\`: orchestration and configuration wrapper.
- \`qwen_ollama_chess_qt/main.cpp\`: Qt/C++ chess/model interaction engine.
- \`qwen_ollama_chess_qt/qwen_ollama_chess_qt.pro\`: Qt project definition.
- \`tools/script_binary_launcher.cpp\`: launcher support.
- \`tools/build_aih_v5.sh\`: launcher build helper.
- \`tools/generate_aih_v5_html_report.cpp\`: current single-run and all-CSV report generator.
- \`tools/generate_aih_v5_repeat_html.cpp\`: registration-repeat aggregate generator.
- \`tools/run_aih_v5_repeat.cpp\`: repeat-run support.
- local-stack discovery/intake/scan scripts under \`tools/\`.

Compiled binaries are build products, not publication source.

## 3. Registration Flow

Registration remains intentionally weaker than gameplay:

1. Discover/select candidate agents.
2. Test each candidate through the configured stack.
3. Record pass/fail, reason, elapsed time, timeout, and later move timing when available.
4. Keep failures in the evidence set.
5. Admit only passing candidates to tournament play.
6. Reset/unload local models between batches when required for stability.

Useful laptop defaults remain approximately:

\`\`\`text
registration timeout      = 5 s
registration batch size   = 5
stack-reset settle        = 5 s
registration order        = random
minimum top-4 entrants    = 4
local keep-alive          = 0 s where supported
\`\`\`

Registration CSV snapshots belong directly under \`v5/data\`.

## 4. Chess Harness

For each measured ply:

1. Maintain the board state and legal UCI move set.
2. Construct a constrained prompt requesting one legal UCI move.
3. Send it to the selected agent/provider path.
4. Parse UCI candidates from the response.
5. Accept a legal candidate.
6. Record illegal, unparseable, irrelevant, empty, timeout, or transport-failed responses as AIH/failure evidence.
7. Record timing and throughput fields when the provider/runtime exposes them.

Default execution should remain serial/conservative on local hardware unless the user explicitly raises concurrency.

## 5. Tournament and Ranking

The primary v5 tournament remains top-4 ladder-rungs:

- seed with round-robin observations;
- identify the top four candidates;
- run bounded head-to-head ladder placement;
- retain lower-rung evidence when more candidates are present.

Ranking semantics:

- AIH% is the primary reliability measure; lower is better.
- Legal/usable response rate is supporting evidence.
- Average legal-event time and AIH-event time expose latency differences.
- Weighted performance and tokens/sec are secondary efficiency measurements where valid data exists.

Do not hide failed registrations or failed move attempts merely because they did not contribute to a successful game result.

## 6. Repeat Runs

Support repeat execution through \`--nruns=N\` and target-registration execution through \`--minregs=N\`.

Repeat behavior should:

- print run progress;
- suppress repeated child-run browser tabs;
- preserve child-run evidence;
- keep active CSV/JSONL data under \`v5/data\`;
- generate one final aggregate report; and
- open only the final report unless explicitly configured otherwise.

## 7. Current All-CSV Analyzer

The current analyzer is implemented in:

\`\`\`text
tools/generate_aih_v5_html_report.cpp
\`\`\`

Build it with a C++17 compiler, then run it from the v5 root with one of its equivalent all-data options:

\`\`\`bash
./<compiled-html-reporter> --csv-all AIH_V5_CSV_AGGREGATE_LATEST.html
\`\`\`

Equivalent recognized switches are \`--csv-data\` and \`--all-csv\`.

The all-CSV path scans \`v5/data\`, combines available ranking CSV, registration CSV, and event JSONL information, writes the requested report, and updates:

- \`AIH_V5_CSV_AGGREGATE_LATEST.html\`
- local mirror \`data/AIH_V5_CSV_AGGREGATE_LATEST.html\`

The broader CSV aggregate is separate from \`AIH_V5_REGISTRATION_AGGREGATE_LATEST.html\`.

${snapshot_line}

## 8. Data Contract

Keep enough machine-readable evidence to recompute the reports. Registration data should retain at least:

\`\`\`text
candidate,status,reason,elapsed_seconds,timeout_seconds,avg_move_seconds,move_attempts
\`\`\`

Event JSONL should retain enough information to reconstruct model identity, legal/illegal outcome, failure class, transport state, elapsed time, and board/ply context.

Ranking CSV should continue to retain base agent identity and ranking configuration. A future schema improvement should add explicit reasoning/verbosity columns before same-model multi-thought-mode runs are merged into one public ranking table.

## 9. Failure Handling

Every run should end with readable status information. If tournament execution fails, the system should still preserve registration/evidence files and generate a status/failure HTML page when practical.

Terminal output should identify start time, selected candidates, registration progress, tournament phase progress, report path, end time, and elapsed time so an apparent hang can be distinguished from a long local inference step.

## 10. Source Publication ZIP

The canonical public source archive is:

\`\`\`text
AIH_V5_SOURCE_LATEST.zip
\`\`\`

Rebuild it at publication time from the current v5 source tree. Include C/C++/Qt source and supporting shell/build files. Exclude:

- compiled executables and object files;
- raw CSV and JSONL data;
- logs and caches;
- \`runs/\`, \`published_results/\`, qualification caches, and other generated output;
- Git metadata; and
- GitHub-publication/handoff helper scripts that are procedure tooling rather than AIH v5 runtime source.

Include a manifest in the archive describing the inclusion/exclusion policy and listing the archived source files.

## 11. Canonical Publication Procedure

A publication update should modify and stage exactly these four repository paths:

\`\`\`text
aih/aichess/v5/AIH_V5_PROJECT_GOALS.md
aih/aichess/v5/AIH_V5_IMPLEMENTATION_PLAN.md
aih/aichess/v5/AIH_V5_CSV_AGGREGATE_LATEST.html
aih/aichess/v5/AIH_V5_SOURCE_LATEST.zip
\`\`\`

Do not stage dated copies, raw run data, binaries, local project-summary files, or unrelated working-tree changes.

Before committing:

1. Confirm the repository is \`gray3s/brilliance\` on branch \`main\`.
2. Fetch \`origin/main\`.
3. Require local HEAD to match remote HEAD before making the publication commit.
4. Refuse to continue if unrelated files are already staged.
5. Regenerate the CSV aggregate.
6. Rebuild the source ZIP.
7. Rewrite the two canonical Markdown files.
8. Stage only the four paths above.
9. Confirm the staged set exactly matches the four-path allowlist.

After committing and pushing, verify the remote bytes of all four canonical files against the local files.

## 12. Local-Only GitHub Procedure Summary

The GitHub-update project summary is operational documentation, not a public AIH v5 artifact. Keep it outside the Git repository at:

\`\`\`text
~/RPA2/gpt/aih/v5/AIH_V5_GITHUB_UPDATE_PROJECT_SUMMARY.txt
\`\`\`

It must never be included in the Git staging allowlist.

## 13. Acceptance Test

The publication process is complete when:

- the four canonical local files exist and are nonempty;
- only those four paths are staged;
- one publication commit is pushed to \`origin/main\`;
- remote \`main\` equals the resulting local commit;
- byte-for-byte verification succeeds for all four remote files; and
- the permanent GitHub/LinkedIn links remain unchanged.
EOF

# ---------------------------------------------------------------------------
# 3. Rebuild source-only ZIP from the current code tree.
# ---------------------------------------------------------------------------
SOURCE_STAGE="$TMP_ROOT/source_stage"
ARCHIVE_ROOT="$SOURCE_STAGE/aih/aichess/v5"
mkdir -p "$ARCHIVE_ROOT"

echo "Collecting current AIH v5 source..."
while IFS= read -r -d '' src; do
  rel="${src#$V5/}"
  case "$rel" in
    aih_v5_github_update_files*.sh|aih_v5_make_chatgpt_handoff*.sh|aih_v5_publish_github.sh|AIH_V5_CHATGPT_HANDOFF*.txt)
      continue
      ;;
  esac
  mkdir -p "$ARCHIVE_ROOT/$(dirname "$rel")"
  cp -p "$src" "$ARCHIVE_ROOT/$rel"
done < <(
  find "$V5" \
    \( -path "$V5/.git" \
       -o -path "$V5/data" \
       -o -path "$V5/logs" \
       -o -path "$V5/runs" \
       -o -path "$V5/published_results" \
       -o -path "$V5/qualification_cache" \
       -o -path "$V5/saved_current_runs_20260803" \
       -o -path "$V5/node_modules" \
       -o -path "$V5/build" \
       -o -path "$V5/.cache" \) -prune -o \
    -type f \
    \( -name '*.c' -o -name '*.cc' -o -name '*.cpp' \
       -o -name '*.h' -o -name '*.hh' -o -name '*.hpp' \
       -o -name '*.pro' -o -name '*.pri' \
       -o -name 'CMakeLists.txt' -o -name 'Makefile' \
       -o -name '*.sh' -o -name 'README.md' \) \
    -print0
)

source_count="$(find "$ARCHIVE_ROOT" -type f | wc -l | tr -d ' ')"
(( source_count > 0 )) || fail "source archive collection found no files"

{
  echo "AIH v5 canonical source archive"
  echo
  echo "Purpose: source-only snapshot for the permanent AIH v5 public source link."
  echo "Repository subtree: aih/aichess/v5"
  echo "Files before manifest: $source_count"
  echo
  echo "Included: C/C++/Qt source, shell runtime/build helpers, build definitions, README."
  echo "Excluded: binaries, object files, raw CSV/JSONL, logs, caches, run output, Git metadata, publication/handoff helpers."
  echo
  echo "Archived files:"
  (cd "$SOURCE_STAGE" && find aih/aichess/v5 -type f ! -name AIH_V5_SOURCE_MANIFEST.txt -print | sort)
} > "$ARCHIVE_ROOT/AIH_V5_SOURCE_MANIFEST.txt"

rm -f "$SOURCE_ZIP"
(
  cd "$SOURCE_STAGE"
  zip -qr "$SOURCE_ZIP" aih
)
[[ -s "$SOURCE_ZIP" ]] || fail "source ZIP was not created"

# Conservative publication safety cap: abort rather than attempting a very
# large binary Git object.
source_zip_bytes="$(stat -c %s "$SOURCE_ZIP")"
(( source_zip_bytes < 99614720 )) || fail "source ZIP exceeds the script's 95 MiB publication safety cap"
source_zip_sha="$(sha256sum "$SOURCE_ZIP" | awk '{print $1}')"

# ---------------------------------------------------------------------------
# 4. Write/update the local-only project summary OUTSIDE the repository.
# ---------------------------------------------------------------------------
mkdir -p "$LOCAL_SUMMARY_DIR"
cat > "$LOCAL_SUMMARY" <<EOF
project: "AIH v5 github content update"

PURPOSE
Maintain four stable public AIH v5 GitHub/LinkedIn targets by replacing their contents without changing their filenames or URLs.

REPOSITORY
$REPO_ROOT
GitHub: https://github.com/$REPO_SLUG
Branch: $BRANCH

FOUR PERMANENT PUBLIC TARGETS
1. Project goals
   $GOALS_URL

2. Implementation plan
   $PLAN_URL

3. Current HTML CSV analysis
   $HTML_URL

4. Current AIH v5 source ZIP
   $SOURCE_URL

LOCAL-ONLY PROCEDURE SUMMARY
This file is deliberately outside the Git repository:
$LOCAL_SUMMARY
It must not be pushed to GitHub.

CURRENT PUBLICATION PROCEDURE
- Fetch origin/main and require local HEAD to equal remote HEAD.
- Refuse to run with any pre-existing staged files.
- Build tools/generate_aih_v5_html_report.cpp with C++17.
- Run its --csv-all path with browser opening disabled.
- Update AIH_V5_CSV_AGGREGATE_LATEST.html.
- Rewrite the canonical project goals and implementation plan.
- Rebuild AIH_V5_SOURCE_LATEST.zip from current source-only content.
- Stage exactly the four canonical publication files.
- Commit and push main.
- Byte-compare all four remote files against the local publication files.

CURRENT ANALYSIS SNAPSHOT
CSV files included: ${CSV_INCLUDED:-current analyzer output}
Ranking CSV files: ${RANKING_FILES:-current analyzer output}
Registration CSV files: ${REGISTRATION_FILES:-current analyzer output}
Ranking rows: ${RANKING_ROWS:-current analyzer output}
Agents ranked: ${AGENTS_RANKED:-current analyzer output}
Total events observed: ${EVENTS_OBSERVED:-current analyzer output}

SOURCE ZIP
Path: $SOURCE_ZIP
Source files before manifest: $source_count
Bytes: $source_zip_bytes
SHA-256: $source_zip_sha

GIT STAGING ALLOWLIST
${PUB_REL[0]}
${PUB_REL[1]}
${PUB_REL[2]}
${PUB_REL[3]}

IMPORTANT DISTINCTION
AIH_V5_CSV_AGGREGATE_LATEST.html is the broad current CSV/data analysis target.
AIH_V5_REGISTRATION_AGGREGATE_LATEST.html is a separate registration-only artifact and is not one of the four permanent LinkedIn targets.
EOF

# ---------------------------------------------------------------------------
# 5. Stage exactly the four public artifacts, commit, push, verify.
# ---------------------------------------------------------------------------
for rel in "${PUB_REL[@]}"; do
  [[ -s "$REPO_ROOT/$rel" ]] || fail "publication artifact missing or empty: $rel"
done

echo "Staging exactly four canonical publication artifacts..."
git add -- "${PUB_REL[@]}"

mapfile -t staged_actual < <(git diff --cached --name-only | sort)
mapfile -t staged_expected < <(printf '%s\n' "${PUB_REL[@]}" | sort)
if [[ "${#staged_actual[@]}" -ne "${#staged_expected[@]}" ]] || \
   [[ "$(printf '%s\n' "${staged_actual[@]}")" != "$(printf '%s\n' "${staged_expected[@]}")" ]]; then
  echo "Expected staged paths:" >&2
  printf '  %s\n' "${staged_expected[@]}" >&2
  echo "Actual staged paths:" >&2
  printf '  %s\n' "${staged_actual[@]}" >&2
  git reset -- "${PUB_REL[@]}" >/dev/null 2>&1 || true
  fail "staged-file allowlist check failed"
fi

if git diff --cached --quiet; then
  fail "the four canonical files have no changes to publish"
fi

echo
echo "Publication diff summary:"
git diff --cached --stat

echo "Committing..."
git commit -m "$COMMIT_MESSAGE" -- "${PUB_REL[@]}"
expected_head="$(git rev-parse HEAD)"

echo "Pushing $BRANCH..."
git push "$REMOTE" "$BRANCH"

remote_head_after="$(git ls-remote "$REMOTE" "refs/heads/$BRANCH" | awk '{print $1}')"
[[ "$remote_head_after" == "$expected_head" ]] || \
  fail "remote HEAD verification failed: expected $expected_head got $remote_head_after"

verify_remote_file() {
  local filename="$1"
  local local_path="$2"
  local tmp="$TMP_ROOT/remote_${filename//\//_}"
  echo "Verifying remote bytes: $filename"
  curl -fsSL --retry 3 --retry-delay 1 "$RAW_BASE/$filename" -o "$tmp"
  cmp -s "$local_path" "$tmp" || fail "remote byte comparison failed for $filename"
  printf '  SHA-256 %s\n' "$(sha256sum "$tmp" | awk '{print $1}')"
}

verify_remote_file "AIH_V5_PROJECT_GOALS.md" "$GOALS"
verify_remote_file "AIH_V5_IMPLEMENTATION_PLAN.md" "$PLAN"
verify_remote_file "AIH_V5_CSV_AGGREGATE_LATEST.html" "$CSV_HTML"
verify_remote_file "AIH_V5_SOURCE_LATEST.zip" "$SOURCE_ZIP"

echo
echo "SUCCESS: AIH v5 canonical publication is live and byte-verified."
echo "Commit: $expected_head"
echo
echo "Permanent links:"
echo "1. $GOALS_URL"
echo "2. $PLAN_URL"
echo "3. $HTML_URL"
echo "4. $SOURCE_URL"
echo
echo "Local-only project summary:"
echo "$LOCAL_SUMMARY"
