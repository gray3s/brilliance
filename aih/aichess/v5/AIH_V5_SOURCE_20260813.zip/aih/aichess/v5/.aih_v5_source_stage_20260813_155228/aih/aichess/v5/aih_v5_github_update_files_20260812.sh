#!/usr/bin/env bash
set -euo pipefail

# AIH v5 GitHub update helper, generated 2026-08-12 and updated 2026-08-13.
# Run from anywhere.
#
# Default behavior stages, commits, and pushes these exact files.
# Use --dry-run to print the file set, specs, GitHub links, and git status
# without changing git state.

REPO_ROOT="/home/sag/RPA2/myLLC/AI/brilliance"
REMOTE_BLOB_BASE="https://github.com/gray3s/brilliance/blob/main"
BRANCH="main"
COMMIT_MESSAGE="Update AIH v5 local-agent core play support"
DO_PUSH=1

usage() {
  cat <<'USAGE'
Usage:
  ./aih_v5_github_update_files_20260812.sh
  ./aih_v5_github_update_files_20260812.sh --dry-run

Default mode stages the listed files, commits them, and pushes to origin/main.
--dry-run prints the planned update without changing git state.
USAGE
}

for arg in "$@"; do
  case "$arg" in
    --dry-run) DO_PUSH=0 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $arg" >&2; usage >&2; exit 2 ;;
  esac
done

relpaths=(
  "aih/aichess/v5/README.md"
  "aih/aichess/v5/RUN_AIH_V5_BINARY_INSTRUCTIONS_20260810.md"
  "aih/aichess/v5/AIH_V5_PROJECT_GOALS.md"
  "aih/aichess/v5/AIH_V5_IMPLEMENTATION_PLAN.md"
  "aih/aichess/v5/aih_v5.sh"
  "aih/aichess/v5/tools/build_aih_v5.sh"
  "aih/aichess/v5/tools/run_aih_v5_single_game.cpp"
  "aih/aichess/v5/tools/generate_aih_v5_html_report.cpp"
  "aih/aichess/v5/AIH_V5_LOCAL_MODEL_CANDIDATE_PLAN_DEEPSEEK_VS_KIMI_20260803.md"
  "aih/aichess/v5/AIH_V5_PROJECT_GOALS_20260810.md"
  "aih/aichess/v5/AIH_V5_IMPLEMENTATION_PLAN_20260810.md"
  "aih/aichess/v5/AIH_V5_CSV_AGGREGATE_LATEST.html"
  "aih/aichess/v5/data/AIH_V5_CSV_AGGREGATE_LATEST.html"
)

echo "# AIH v5 GitHub Update Files"
echo
echo "Repository root: ${REPO_ROOT}"
echo "GitHub base: ${REMOTE_BLOB_BASE}"
echo "Branch: ${BRANCH}"
echo "Mode: $([[ "${DO_PUSH}" == "1" ]] && echo push || echo dry-run)"
echo
echo "| Local source filespec | Size bytes | Modified | SHA-256 | GitHub link |"
echo "|---|---:|---|---|---|"

for relpath in "${relpaths[@]}"; do
  path="${REPO_ROOT}/${relpath}"
  if [[ ! -r "${path}" ]]; then
    echo "Missing update file: ${path}" >&2
    exit 2
  fi
  size="$(wc -c < "${path}")"
  modified="$(date -r "${path}" '+%Y-%m-%d %H:%M:%S %z')"
  sha256="$(sha256sum "${path}" | awk '{print $1}')"
  echo "| \`${REPO_ROOT}/${relpath}\` | ${size} | ${modified} | \`${sha256}\` | ${REMOTE_BLOB_BASE}/${relpath} |"
done

echo
echo "Commit message: ${COMMIT_MESSAGE}"
echo
echo "Review helper in gedit:"
echo "  gedit ${REPO_ROOT}/aih/aichess/v5/aih_v5_github_update_files_20260812.sh"

cd "${REPO_ROOT}"

echo
echo "Current git status for update files:"
git status --short -- "${relpaths[@]}"

if [[ "${DO_PUSH}" != "1" ]]; then
  echo
  echo "Dry run only. To push, run:"
  echo "  $0"
  exit 0
fi

current_branch="$(git branch --show-current)"
if [[ "${current_branch}" != "${BRANCH}" ]]; then
  echo "Refusing to push from branch '${current_branch}'. Expected '${BRANCH}'." >&2
  exit 2
fi

echo
echo "Staging update files..."
git add -- "${relpaths[@]}"

if git diff --cached --quiet -- "${relpaths[@]}"; then
  echo "No staged changes in the AIH v5 update file set; nothing to commit or push."
  exit 0
fi

echo "Committing..."
git commit -m "${COMMIT_MESSAGE}" -- "${relpaths[@]}"

echo "Pushing to origin/${BRANCH}..."
git push origin "${BRANCH}"

echo
echo "Pushed. GitHub links:"
for relpath in "${relpaths[@]}"; do
  echo "${REMOTE_BLOB_BASE}/${relpath}"
done
