#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_HTML="${1:-$ROOT_DIR/AIH_V5_PRELIMINARY_RESULTS_20260810.html}"
DATA_DIR="$ROOT_DIR/data"
RUN_DIR="$ROOT_DIR/runs/aih_v5_pairwise_prototype_20260729"
REG_CSV="${AIH_V5_REGISTRATION_STATUS_CSV:-$ROOT_DIR/AIH_V5_REGISTRATION_STATUS.csv}"
OPEN_HTML="${AIH_V5_HTML_OPEN:-1}"

latest_summary="$(
  find "$DATA_DIR" "$RUN_DIR" -maxdepth 1 -type f -name '*_summary.md' -printf '%T@ %p\n' 2>/dev/null |
    sort -nr |
    awk 'NR == 1 { $1=""; sub(/^ /, ""); print }'
)"

if [[ -z "$latest_summary" || ! -r "$latest_summary" ]]; then
  echo "aih_v5_html: no summary file found in $DATA_DIR or $RUN_DIR" >&2
  exit 2
fi

latest_jsonl="${latest_summary%_summary.md}.jsonl"
if [[ ! -r "$latest_jsonl" ]]; then
  alt_jsonl="$DATA_DIR/$(basename "$latest_jsonl")"
  if [[ -r "$alt_jsonl" ]]; then
    latest_jsonl="$alt_jsonl"
  else
    echo "aih_v5_html: no JSONL found for summary: $latest_summary" >&2
    exit 2
  fi
fi

mkdir -p "$(dirname "$OUT_HTML")" "$DATA_DIR"
published_summary="$DATA_DIR/$(basename "$latest_summary")"
published_jsonl="$DATA_DIR/$(basename "$latest_jsonl")"
published_html="$DATA_DIR/$(basename "${latest_summary%_summary.md}.html")"

if [[ "$latest_summary" != "$published_summary" ]]; then
  cp "$latest_summary" "$published_summary"
fi
if [[ "$latest_jsonl" != "$published_jsonl" ]]; then
  cp "$latest_jsonl" "$published_jsonl"
fi

html_escape_awk='function esc(s) { gsub(/&/, "\\&amp;", s); gsub(/</, "\\&lt;", s); gsub(/>/, "\\&gt;", s); return s }'

emit_rows() {
  local jsonl="$1"
  jq -r '
    .events[]? |
    .model as $model |
    if (.transport_failure == true or .error == "move_request_transport_failure" or .response.status == "request_failed") then
      [$model, "transport"]
    elif (.legal_by_rules == true or .legal == true) then
      [$model, "legal"]
    elif ((.error // "") | test("hallucination|illegal_move|unparseable_move|invalid_move|no_candidate")) then
      [$model, "agent_fail"]
    elif (.irrelevant_agent_return == true or .error == "irrelevant_agent_return") then
      [$model, "agent_fail"]
    else
      [$model, "agent_fail"]
    end |
    @tsv
  ' "$jsonl" |
    awk -F '\t' '
      function pct(n, d) { return d > 0 ? (100.0 * n / d) : -1 }
      function label(model) {
        if (model ~ /^openai:/) { sub(/^openai:/, "", model); return "0 openai " model }
        if (model ~ /^anthropic:/) { sub(/^anthropic:/, "", model); return "0 anthropic " model }
        if (model ~ /^gemini:/) { sub(/^gemini:/, "", model); return "0 google " model }
        if (model ~ /^google:/) { sub(/^google:/, "", model); return "0 google " model }
        return "1 ollama " model
      }
      {
        agent = label($1)
        seen[agent] = 1
        total[agent]++
        if ($2 == "legal") legal[agent]++
        else if ($2 == "agent_fail") agent_fail[agent]++
        else transport[agent]++
      }
      END {
        for (agent in seen) {
          scored = legal[agent] + agent_fail[agent] + transport[agent]
          aih = pct(agent_fail[agent], scored)
          legal_pct = pct(legal[agent], scored)
          printf "%.8f\t%.8f\t%s\n", aih, legal_pct, agent
        }
      }
    ' |
    sort -t $'\t' -k1,1n -k2,2nr -k3,3 |
    awk -F '\t' '
      function fmt(x) { return sprintf("%06.3f", x + 0) }
      function cls(p) { return p >= 60 ? "aih-high" : p >= 20 ? "aih-mid" : "aih-low" }
      '"$html_escape_awk"'
      {
        rank = NR
        split($3, parts, " ")
        local_flag = parts[1]
        title = substr($3, length(parts[1]) + 2)
        printf "        <tr><td class=\"num\">%d</td><td class=\"num %s\">%s</td><td class=\"num\">%s</td><td class=\"num\">%s</td><td>%s</td><td>0/1 (000.00%%)</td></tr>\n",
          rank, cls($1), fmt($1), fmt($2), local_flag, esc(title)
      }'
}

emit_registration_fail_rows() {
  local csv="$1"
  [[ -r "$csv" ]] || return 0
  awk -F, '
    '"$html_escape_awk"'
    NR > 1 && $2 != "pass" {
      failed[$1]++
      if ($3 ~ /timed out/) timeouts[$1]++
    }
    END {
      for (agent in failed) {
        pct = failed[agent] ? 100.0 * timeouts[agent] / failed[agent] : 0.0
        printf "%s\t%d/%d (%06.2f%%)\n", agent, timeouts[agent], failed[agent], pct
      }
    }' "$csv" |
    sort -f -k1,1 |
    awk -F '\t' '
      '"$html_escape_awk"'
      {
        printf "        <tr><td class=\"num\">n/a</td><td class=\"num\">n/a</td><td class=\"num\">n/a</td><td class=\"num\">1</td><td>ollama %s</td><td>%s</td></tr>\n", esc($1), esc($2)
      }'
}

emit_efficiency() {
  local jsonl="$1"
  local reg_csv="$2"
  local reg_elapsed="n/a"
  if [[ -r "$reg_csv" ]]; then
    reg_elapsed="$(awk -F, 'NR > 1 { s += $4 + 0 } END { printf "%.3f", s }' "$reg_csv")"
  fi
  jq -rs --arg reg_elapsed "$reg_elapsed" '
    [ .[] | .events[]? ] as $events |
    ($events | length) as $plies |
    ($events | map(.move_to_referee_elapsed_s // .response.elapsed_s // 0) | add // 0) as $tournament_elapsed |
    ($events | map(.board_id // .board // empty) | unique | length) as $boards |
    ($reg_elapsed | tonumber? // 0) as $reg |
    "<h2>Efficiency Measurements</h2>",
    "<table>",
    "<thead><tr><th>Metric</th><th class=\"num\">Value</th></tr></thead>",
    "<tbody>",
    ("<tr><td>Registration elapsed seconds</td><td class=\"num\">" + ($reg_elapsed|tostring) + "</td></tr>"),
    ("<tr><td>Tournament elapsed seconds</td><td class=\"num\">" + ($tournament_elapsed|tostring) + "</td></tr>"),
    ("<tr><td>Total measured seconds</td><td class=\"num\">" + (($reg + $tournament_elapsed)|tostring) + "</td></tr>"),
    ("<tr><td>Tournament boards</td><td class=\"num\">" + ($boards|tostring) + "</td></tr>"),
    ("<tr><td>Tournament plies played</td><td class=\"num\">" + ($plies|tostring) + "</td></tr>"),
    ("<tr><td>Tournament seconds per played ply</td><td class=\"num\">" + (if $plies > 0 then ($tournament_elapsed / $plies) else 0 end | tostring) + "</td></tr>"),
    "</tbody>",
    "</table>"
  ' "$jsonl"
}

open_html_report() {
  local html="$1"
  local html_uri
  if [[ "$OPEN_HTML" != "1" && "$OPEN_HTML" != "yes" && "$OPEN_HTML" != "true" ]]; then
    return 0
  fi
  if [[ ! -r "$html" ]]; then
    echo "aih_v5_html: cannot open missing report: $html" >&2
    return 0
  fi
  html="$(readlink -f "$html")"
  html_uri="file://$html"
  echo "aih_v5_html: opening $html_uri" >&2
  if command -v gio >/dev/null 2>&1; then
    gio open "$html_uri" >/dev/null 2>&1 &
    return 0
  fi
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$html_uri" >/dev/null 2>&1 &
    return 0
  fi
  if command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "$html" >/dev/null 2>&1 &
    return 0
  fi
  echo "aih_v5_html: no default browser opener found for $html" >&2
}

{
  cat <<HTML
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>AIH v5 latest run</title>
  <style>body{font-family:Arial,sans-serif;margin:2rem;line-height:1.45;color:#1f2933}table{border-collapse:collapse;width:100%;margin-top:1rem}th,td{border:1px solid #cad2dc;padding:.55rem;text-align:left;vertical-align:top}th{background:#eef2f6}.note{color:#52606d}code{background:#eef2f6;padding:.1rem .25rem;border-radius:3px}td.num{text-align:right;font-variant-numeric:tabular-nums}.aih-high{color:#b42318;font-weight:700}.aih-mid{color:#8a5a00;font-weight:700}.aih-low{color:#146c43;font-weight:700}</style>
</head>
<body>
  <main>
    <h1>AIH v5 latest run</h1>
    <p class="note">Summary: <code>data/$(basename "$published_summary")</code></p>
    <p class="note">JSONL: <code>data/$(basename "$published_jsonl")</code></p>
    <p class="note">AIH% is the agent-output failure rate. Lower is better.</p>
    <table>
      <thead><tr><th>Rank</th><th class="num">AIH%</th><th class="num">Legal%</th><th class="num">Local?</th><th>Agent Title</th><th>Reg. T.O.</th></tr></thead>
      <tbody>
HTML
  emit_rows "$published_jsonl"
  emit_registration_fail_rows "$REG_CSV"
  cat <<HTML
      </tbody>
    </table>
HTML
  emit_efficiency "$published_jsonl" "$REG_CSV"
  cat <<HTML
  </main>
</body>
</html>
HTML
} > "$OUT_HTML"

if [[ "$OUT_HTML" != "$published_html" ]]; then
  cp "$OUT_HTML" "$published_html"
fi

echo "aih_v5_html: wrote $OUT_HTML"
echo "aih_v5_html: wrote $published_html"
open_html_report "$OUT_HTML"
