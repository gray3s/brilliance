#include <errno.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include <iostream>
#include <string>
#include <vector>

#ifndef SCRIPT_REL_PATH
#error "SCRIPT_REL_PATH must be defined at compile time"
#endif

static std::string dirnameOf(const std::string &path) {
    const std::string::size_type pos = path.find_last_of('/');
    if (pos == std::string::npos) {
        return ".";
    }
    if (pos == 0) {
        return "/";
    }
    return path.substr(0, pos);
}

static std::string canonicalPath(const std::string &path) {
    char resolved[PATH_MAX];
    if (realpath(path.c_str(), resolved) == nullptr) {
        return path;
    }
    return std::string(resolved);
}

static bool endsWith(const std::string &value, const std::string &suffix) {
    return value.size() >= suffix.size() &&
           value.compare(value.size() - suffix.size(), suffix.size(), suffix) == 0;
}

static std::string localTimestamp(time_t value) {
    char buffer[64];
    struct tm tmValue;
    if (localtime_r(&value, &tmValue) == nullptr) {
        return "unknown";
    }
    if (strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S %Z", &tmValue) == 0) {
        return "unknown";
    }
    return std::string(buffer);
}

static std::string selfPath(const char *argv0) {
    char buffer[PATH_MAX + 1];
    const ssize_t len = readlink("/proc/self/exe", buffer, PATH_MAX);
    if (len > 0) {
        buffer[len] = '\0';
        return std::string(buffer);
    }

    char resolved[PATH_MAX + 1];
    if (argv0 != nullptr && realpath(argv0, resolved) != nullptr) {
        return std::string(resolved);
    }

    return argv0 == nullptr ? std::string(".") : std::string(argv0);
}

static bool executableFile(const std::string &path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode) && access(path.c_str(), X_OK) == 0;
}

static std::string shellQuote(const std::string &value) {
    if (value.empty()) {
        return "''";
    }

    bool plain = true;
    for (const char ch : value) {
        const bool safe =
            (ch >= 'A' && ch <= 'Z') ||
            (ch >= 'a' && ch <= 'z') ||
            (ch >= '0' && ch <= '9') ||
            ch == '_' || ch == '-' || ch == '.' || ch == '/' || ch == ':' || ch == '=';
        if (!safe) {
            plain = false;
            break;
        }
    }
    if (plain) {
        return value;
    }

    std::string quoted = "'";
    for (const char ch : value) {
        if (ch == '\'') {
            quoted += "'\\''";
        } else {
            quoted += ch;
        }
    }
    quoted += "'";
    return quoted;
}

int main(int argc, char **argv) {
    const std::string executable = selfPath(argc > 0 ? argv[0] : nullptr);
    const std::string binDir = dirnameOf(executable);
    const std::string repoRoot = canonicalPath(dirnameOf(binDir));
    const std::string scriptPath = repoRoot + "/" + SCRIPT_REL_PATH;

    if (!endsWith(repoRoot, "/aih/aichess/v5")) {
        std::cerr << "script launcher: refusing to run outside the AIH v5 tree: "
                  << repoRoot << "\n";
        return 127;
    }

    if (getenv("AICHESS_BINARY_TRACE") != nullptr) {
        std::cerr << "script launcher: exe=" << executable << "\n";
        std::cerr << "script launcher: repo_root=" << repoRoot << "\n";
        std::cerr << "script launcher: script=" << scriptPath << "\n";
    }

    if (!executableFile(scriptPath)) {
        std::cerr << "script launcher: target is not executable: " << scriptPath << "\n";
        return 127;
    }

    std::string launchString = shellQuote(argc > 0 && argv[0] != nullptr ? argv[0] : executable);
    for (int i = 1; i < argc; ++i) {
        launchString += " ";
        launchString += shellQuote(argv[i] == nullptr ? std::string() : std::string(argv[i]));
    }
    setenv("AIH_V5_ORIGINAL_LAUNCH_STRING", launchString.c_str(), 1);
    setenv("AIH_V5_SUPPRESS_EXIT_FOOTER", "1", 1);

    std::vector<char *> execArgs;
    execArgs.reserve(static_cast<size_t>(argc) + 1);
    execArgs.push_back(const_cast<char *>(scriptPath.c_str()));
    for (int i = 1; i < argc; ++i) {
        execArgs.push_back(argv[i]);
    }
    execArgs.push_back(nullptr);

    const time_t startTime = time(nullptr);
    const pid_t pid = fork();
    if (pid < 0) {
        std::cerr << "script launcher: fork failed for " << scriptPath << ": " << strerror(errno) << "\n";
        return 126;
    }

    if (pid == 0) {
        execv(scriptPath.c_str(), execArgs.data());
        std::cerr << "script launcher: exec failed for " << scriptPath << ": " << strerror(errno) << "\n";
        _exit(126);
    }

    int status = 0;
    while (waitpid(pid, &status, 0) < 0) {
        if (errno != EINTR) {
            std::cerr << "script launcher: wait failed for " << scriptPath << ": " << strerror(errno) << "\n";
            return 126;
        }
    }

    const time_t endTime = time(nullptr);
    long elapsed = static_cast<long>(endTime - startTime);
    if (elapsed < 0) {
        elapsed = 0;
    }
    std::cerr << "end timestamp: " << localTimestamp(endTime) << "\n";
    std::cerr << "elapsed time notes: runtime=";
    std::cerr.width(2);
    std::cerr.fill('0');
    std::cerr << (elapsed / 60);
    std::cerr << ":";
    std::cerr.width(2);
    std::cerr.fill('0');
    std::cerr << (elapsed % 60) << " elapsed_seconds=" << elapsed << "\n";
    std::cerr << "aih_v5: launch: " << launchString << "\n";

    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return 126;
}
