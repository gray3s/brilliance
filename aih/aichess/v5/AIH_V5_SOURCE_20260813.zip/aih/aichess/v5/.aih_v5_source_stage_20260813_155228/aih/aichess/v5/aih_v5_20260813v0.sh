#!/usr/bin/env bash
set -euo pipefail

cd /home/sag/RPA2/myLLC/AI/brilliance/aih/aichess/v5

LOG_DIR="./logs/single_game"

echo "[aih-v5-diagnostic] starting clean local-agent diagnostic"
echo "[aih-v5-diagnostic] timestamp: $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "[aih-v5-diagnostic] working directory: $(pwd)"
echo "[aih-v5-diagnostic] binary: ./bin/aih_v5_single_game"
echo "[aih-v5-diagnostic] log directory: ${LOG_DIR}"
echo "[aih-v5-diagnostic] move-timeout=120 stack-timeout=75 max-plies=2 output-tokens=64"
echo "[aih-v5-diagnostic] models: 16"
echo "[aih-v5-diagnostic] launching binary now; this may run quietly while logs are written"
echo

set +e
./bin/aih_v5_single_game --local-agent-diagnostic \
  --move-timeout=120 \
  --stack-timeout=75 \
  --max-plies=2 \
  --output-tokens=64 \
  gemma3:270m \
  qwen2.5:0.5b \
  smollm2:135m \
  tinyllama:latest \
  gemma3:1b \
  llama3.2:1b \
  qwen2.5-coder:3b \
  llama3.2:3b \
  phi3:mini \
  granite4:3b \
  qwen:4b \
  nemotron-3-nano:4b \
  gemma3:4b \
  mistral:latest \
  qwen2.5:latest \
  robit/qwen3.5-9b-r7-research:q4km
status=$?
set -e

echo
echo "[aih-v5-diagnostic] binary exited with status: ${status}"
echo "[aih-v5-diagnostic] finished at: $(date '+%Y-%m-%d %H:%M:%S %Z')"

latest_log="$(
  find "${LOG_DIR}" \
    -maxdepth 1 \
    -type f \
    -name 'aih_v5_local_agent_diagnostic_*_models16_nruns1.log' \
    -printf '%T@ %p\n' 2>/dev/null \
    | sort -nr \
    | sed -n '1s/^[^ ]* //p'
)"

if [[ -n "${latest_log}" ]]; then
  echo "[aih-v5-diagnostic] latest diagnostic log: ${latest_log}"
  echo "[aih-v5-diagnostic] latest diagnostic log size: $(wc -c < "${latest_log}") bytes"
else
  echo "[aih-v5-diagnostic] no matching diagnostic log found in ${LOG_DIR}"
fi

exit "${status}"
