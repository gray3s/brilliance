#!/usr/bin/env bash
set -u
set -o pipefail

# AIH v5 local handoff + source archive generator
#
# Produces:
#   1. Current AIH v5 CSV aggregate HTML, when a recognizable local analyzer
#      can be safely identified and run.
#   2. A source-only AIH v5 ZIP containing current C/C++/Qt source and
#      supporting build/launcher scripts, excluding binaries, raw CSVs,
#      JSONL data, object files, logs, caches, and generated run data.
#   3. A single pasteable ChatGPT handoff text file.
#   4. Opens the handoff text file in gedit.
#
# Intended project:
#   "AIH v5 github content update"
#
# GitHub publication targets after ChatGPT updates the documentation:
#   AIH_V5_PROJECT_GOALS.md
#   AIH_V5_IMPLEMENTATION_PLAN.md
#   AIH_V5_CSV_AGGREGATE_LATEST.html
#   AIH_V5_SOURCE_LATEST.zip

ROOT="/home/sag/RPA2/myLLC/AI/brilliance/aih/aichess/v5"
REPO="/home/sag/RPA2/myLLC/AI/brilliance"

TODAY="$(date +%Y%m%d)"
STAMP="$(date +%Y%m%d_%H%M%S)"

SUMMARY="${ROOT}/AIH_V5_CHATGPT_HANDOFF_${STAMP}.txt"
ANALYZER_LOG="${ROOT}/AIH_V5_CSV_ANALYZER_${STAMP}.log"

CANONICAL_CSV_HTML="${ROOT}/AIH_V5_CSV_AGGREGATE_LATEST.html"
DATED_CSV_HTML="${ROOT}/AIH_V5_CSV_AGGREGATE_${TODAY}.html"
DATA_CSV_HTML="${ROOT}/data/AIH_V5_CSV_AGGREGATE_LATEST.html"

SOURCE_ZIP_DATED="${ROOT}/AIH_V5_SOURCE_${TODAY}.zip"
SOURCE_ZIP_LATEST="${ROOT}/AIH_V5_SOURCE_LATEST.zip"
SOURCE_STAGE="${ROOT}/.aih_v5_source_stage_${STAMP}"

say() {
  printf '\n==> %s\n' "$*"
}

warn() {
  printf 'WARNING: %s\n' "$*" >&2
}

die() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 2
}

[[ -d "$ROOT" ]] || die "AIH v5 directory not found: $ROOT"

command -v zip >/dev/null 2>&1 || die "'zip' is required to build the source archive."

cd "$ROOT" || exit 2

###############################################################################
# 1. CSV ANALYZER DISCOVERY / EXECUTION
###############################################################################

ANALYZER_STATUS="NOT RUN"
ANALYZER_COMMAND=""
ANALYZER_OUTPUT=""
ANALYZER_NOTE=""

run_analyzer_command() {
  ANALYZER_COMMAND="$*"
  say "Running CSV analyzer: $ANALYZER_COMMAND"

  {
    printf 'AIH v5 CSV analyzer launch\n'
    printf 'timestamp: %s\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
    printf 'command: %s\n\n' "$ANALYZER_COMMAND"
  } >"$ANALYZER_LOG"

  if "$@" >>"$ANALYZER_LOG" 2>&1; then
    ANALYZER_STATUS="PASS"
  else
    rc=$?
    ANALYZER_STATUS="FAILED rc=${rc}"
    warn "Analyzer command returned ${rc}. See ${ANALYZER_LOG}"
  fi
}

say "Discovering a recognizable local AIH v5 CSV analyzer"

KNOWN_ANALYZERS=(
  "${ROOT}/bin/aih_v5_csv_analyzer"
  "${ROOT}/bin/aih_v5_csv_aggregate"
  "${ROOT}/bin/aih_v5_csv_aggregate_html"
  "${ROOT}/tools/aih_v5_csv_analyzer.sh"
  "${ROOT}/tools/generate_aih_v5_csv_aggregate.sh"
  "${ROOT}/tools/aih_v5_csv_aggregate.sh"
  "${ROOT}/aih_v5_csv_analyzer.sh"
  "${ROOT}/aih_v5_csv_aggregate.sh"
)

for candidate in "${KNOWN_ANALYZERS[@]}"; do
  if [[ -f "$candidate" ]]; then
    case "$candidate" in
      *.sh)
        run_analyzer_command bash "$candidate"
        ;;
      *)
        if [[ -x "$candidate" ]]; then
          run_analyzer_command "$candidate"
        else
          warn "Analyzer candidate exists but is not executable: $candidate"
          continue
        fi
        ;;
    esac
    break
  fi
done

# Conservative discovery in main launcher:
# execute only if exactly one clearly CSV-analysis-related option is present.
if [[ "$ANALYZER_STATUS" == "NOT RUN" && -f "${ROOT}/aih_v5.sh" ]]; then
  mapfile -t launcher_opts < <(
    grep -Eo -- '--[A-Za-z0-9][A-Za-z0-9_-]*' "${ROOT}/aih_v5.sh" 2>/dev/null |
      grep -Ei 'csv' |
      grep -Ei 'aggregate|analy|summary' |
      sort -u
  )

  if (( ${#launcher_opts[@]} == 1 )); then
    opt="${launcher_opts[0]}"
    run_analyzer_command bash "${ROOT}/aih_v5.sh" "$opt"
  elif (( ${#launcher_opts[@]} > 1 )); then
    ANALYZER_NOTE="Multiple CSV-related launcher options found; none auto-executed: ${launcher_opts[*]}"
  fi
fi

mapfile -t ANALYZER_REFERENCES < <(
  grep -RIl \
    --exclude='*.csv' \
    --exclude='*.jsonl' \
    --exclude='*.html' \
    --exclude='*.zip' \
    --exclude-dir='.git' \
    --exclude-dir='logs' \
    'AIH_V5_CSV_AGGREGATE_LATEST\.html' \
    "$ROOT" 2>/dev/null |
  sort
)

if [[ "$ANALYZER_STATUS" == "NOT RUN" && -z "$ANALYZER_NOTE" ]]; then
  if (( ${#ANALYZER_REFERENCES[@]} > 0 )); then
    ANALYZER_NOTE="No safely recognizable analyzer launcher was auto-run. Source/script references to the CSV aggregate are included in the handoff."
  else
    ANALYZER_NOTE="No safely recognizable analyzer launcher or source reference was found."
  fi
fi

say "Locating newest CSV aggregate HTML"

NEWEST_HTML="$(
  find "$ROOT" "$ROOT/data" -maxdepth 1 -type f \
    -name 'AIH_V5_CSV_AGGREGATE_*.html' \
    ! -name 'AIH_V5_CSV_AGGREGATE_LATEST.html' \
    -printf '%T@ %p\n' 2>/dev/null |
  sort -nr |
  awk 'NR==1 {sub(/^[^ ]+ /,""); print; exit}'
)"

if [[ -z "$NEWEST_HTML" && -f "$CANONICAL_CSV_HTML" ]]; then
  NEWEST_HTML="$CANONICAL_CSV_HTML"
fi

if [[ -z "$NEWEST_HTML" && -f "$DATA_CSV_HTML" ]]; then
  NEWEST_HTML="$DATA_CSV_HTML"
fi

if [[ -n "$NEWEST_HTML" && -f "$NEWEST_HTML" ]]; then
  ANALYZER_OUTPUT="$NEWEST_HTML"

  cp -f -- "$NEWEST_HTML" "$CANONICAL_CSV_HTML"
  cp -f -- "$NEWEST_HTML" "$DATED_CSV_HTML"

  mkdir -p "${ROOT}/data"
  cp -f -- "$NEWEST_HTML" "$DATA_CSV_HTML"

  say "CSV aggregate normalized to"
  printf '  %s\n' "$CANONICAL_CSV_HTML"
  printf '  %s\n' "$DATED_CSV_HTML"
  printf '  %s\n' "$DATA_CSV_HTML"
else
  warn "No AIH_V5_CSV_AGGREGATE_*.html file was found."
fi

###############################################################################
# 2. BUILD SOURCE-ONLY AIH V5 ZIP
###############################################################################

say "Building source-only AIH v5 ZIP"

rm -rf -- "$SOURCE_STAGE"
mkdir -p "$SOURCE_STAGE/aih/aichess/v5"

SOURCE_STAGE_V5="$SOURCE_STAGE/aih/aichess/v5"

copy_source_file() {
  local src="$1"
  [[ -f "$src" ]] || return 0

  local rel="${src#${ROOT}/}"
  local dst="${SOURCE_STAGE_V5}/${rel}"

  mkdir -p "$(dirname "$dst")"
  cp -p -- "$src" "$dst"
}

# Main control / build scripts useful with the C/C++/Qt sources.
for f in \
  "${ROOT}/aih_v5.sh" \
  "${ROOT}/README.md"
do
  copy_source_file "$f"
done

# Copy source recursively while excluding generated/binary/data material.
while IFS= read -r -d '' f; do
  copy_source_file "$f"
done < <(
  find "$ROOT" -type f \
    \( -name '*.c' -o -name '*.cc' -o -name '*.cpp' -o \
       -name '*.h' -o -name '*.hh' -o -name '*.hpp' -o \
       -name '*.pro' -o -name 'CMakeLists.txt' -o \
       -name 'Makefile' -o -name '*.pri' -o -name '*.sh' \) \
    ! -path '*/.git/*' \
    ! -path '*/logs/*' \
    ! -path '*/data/*' \
    ! -path '*/runs/*' \
    ! -path '*/published_results/*' \
    ! -path '*/qualification_cache/*' \
    ! -path '*/node_modules/*' \
    ! -path '*/build/*' \
    ! -path '*/.cache/*' \
    ! -path "${SOURCE_STAGE}/*" \
    -print0
)

# Add a manifest specifically describing the archive.
SOURCE_MANIFEST="${SOURCE_STAGE_V5}/AIH_V5_SOURCE_MANIFEST.txt"

{
  printf 'AIH v5 source-only archive\n'
  printf 'Generated: %s\n' "$(date '+%Y-%m-%d %H:%M:%S %Z')"
  printf 'Source root: %s\n' "$ROOT"
  printf '\nPurpose:\n'
  printf 'Current AIH v5 C/C++/Qt and supporting source code for public review/recreation.\n'
  printf '\nExplicitly excluded:\n'
  printf '- compiled executables/binaries\n'
  printf '- *.o and other object files\n'
  printf '- raw CSV data\n'
  printf '- JSONL event/run data\n'
  printf '- logs\n'
  printf '- caches\n'
  printf '- generated run output\n'
  printf '\nIncluded files:\n'
  (
    cd "$SOURCE_STAGE" || exit
    find aih/aichess/v5 -type f -printf '%p\n' | sort
  )
} >"$SOURCE_MANIFEST"

rm -f -- "$SOURCE_ZIP_DATED" "$SOURCE_ZIP_LATEST"

(
  cd "$SOURCE_STAGE" || exit 2
  zip -q -r "$SOURCE_ZIP_DATED" aih
)

cp -f -- "$SOURCE_ZIP_DATED" "$SOURCE_ZIP_LATEST"

SOURCE_ZIP_COUNT="$(
  unzip -Z1 "$SOURCE_ZIP_DATED" 2>/dev/null |
  grep -v '/$' |
  wc -l
)"

SOURCE_ZIP_SHA="$(
  sha256sum "$SOURCE_ZIP_DATED" | awk '{print $1}'
)"

rm -rf -- "$SOURCE_STAGE"

printf 'Created source ZIP:\n'
printf '  %s\n' "$SOURCE_ZIP_DATED"
printf '  %s\n' "$SOURCE_ZIP_LATEST"
printf '  files: %s\n' "$SOURCE_ZIP_COUNT"
printf '  sha256: %s\n' "$SOURCE_ZIP_SHA"

###############################################################################
# 3. BUILD SINGLE PASTEABLE HANDOFF TEXT FILE
###############################################################################

say "Building single pasteable AIH v5 handoff file"

exec 3>"$SUMMARY"

section() {
  printf '\n\n====================================================================\n' >&3
  printf '%s\n' "$1" >&3
  printf '====================================================================\n\n' >&3
}

emit_file() {
  local f="$1"
  local rel="${f#${ROOT}/}"

  [[ -f "$f" ]] || return 0

  section "FILE: ${rel}"
  printf 'absolute_path: %s\n' "$f" >&3
  printf 'size_bytes: ' >&3
  stat -c '%s' "$f" >&3 2>/dev/null || printf 'unknown\n' >&3
  printf 'sha256: ' >&3
  sha256sum "$f" 2>/dev/null | awk '{print $1}' >&3 || printf 'unknown\n' >&3
  printf '\n----- BEGIN CONTENT -----\n' >&3
  cat "$f" >&3
  printf '\n----- END CONTENT -----\n' >&3
}

cat >&3 <<EOF
AIH v5 ChatGPT handoff
Generated: $(date '+%Y-%m-%d %H:%M:%S %Z')
Project root: $ROOT
Repository root: $REPO

PROJECT
"AIH v5 github content update"

PRIMARY GOAL
Update and publish the current AIH v5 public project artifacts to:
https://github.com/gray3s/brilliance

FOUR PERMANENT PUBLIC/LINKEDIN TARGETS
1. Project goals:
   https://github.com/gray3s/brilliance/blob/main/aih/aichess/v5/AIH_V5_PROJECT_GOALS.md

2. Implementation plan:
   https://github.com/gray3s/brilliance/blob/main/aih/aichess/v5/AIH_V5_IMPLEMENTATION_PLAN.md

3. Current HTML CSV analysis:
   https://htmlpreview.github.io/?https://github.com/gray3s/brilliance/blob/main/aih/aichess/v5/AIH_V5_CSV_AGGREGATE_LATEST.html

4. Current AIH v5 source ZIP:
   https://github.com/gray3s/brilliance/blob/main/aih/aichess/v5/AIH_V5_SOURCE_LATEST.zip

EXPECTED CHATGPT WORK AFTER THIS FILE IS PASTED
- Analyze the current AIH v5 state represented here.
- Generate an updated AIH_V5_PROJECT_GOALS.md.
- Generate an updated dated project-goals copy for the current update.
- Generate an updated AIH_V5_IMPLEMENTATION_PLAN.md.
- Generate an updated dated implementation-plan copy for the current update.
- Preserve/publish the current CSV aggregate HTML.
- Preserve/publish the current source-only ZIP.
- Generate the final Bash GitHub update script.
- The update script must stage only the intended AIH v5 publication artifacts.
- The update script must commit/push to gray3s/brilliance main.
- The update script must verify the four permanent targets after push.

CSV ANALYZER STATUS
status: $ANALYZER_STATUS
command: ${ANALYZER_COMMAND:-<none>}
log: $ANALYZER_LOG
output_selected: ${ANALYZER_OUTPUT:-<none>}
note: ${ANALYZER_NOTE:-<none>}

SOURCE ARCHIVE
dated: $SOURCE_ZIP_DATED
latest: $SOURCE_ZIP_LATEST
files: $SOURCE_ZIP_COUNT
sha256: $SOURCE_ZIP_SHA

INTENTIONAL HANDOFF EXCLUSIONS
- Raw CSV contents
- JSONL run/event contents
- Compiled binaries
- Object files
- Logs
- Cache contents
EOF

section "GIT STATE"

if [[ -d "${REPO}/.git" ]]; then
  (
    cd "$REPO" || exit

    printf 'branch: '
    git branch --show-current 2>/dev/null || true

    printf 'HEAD: '
    git rev-parse HEAD 2>/dev/null || true

    printf 'origin: '
    git remote get-url origin 2>/dev/null || true

    printf '\n--- git status --short --\n'
    git status --short -- aih/aichess/v5 2>/dev/null || true

    printf '\n--- recent commits touching v5 --\n'
    git log -n 12 --date=iso \
      --pretty=format:'%h %ad %s' \
      -- aih/aichess/v5 2>/dev/null || true

    printf '\n'
  ) >&3
else
  printf 'Repository metadata unavailable: %s/.git not found\n' "$REPO" >&3
fi

section "AIH V5 HUMAN-READABLE/SOURCE INVENTORY"

find "$ROOT" -maxdepth 3 -type f \
  \( -name '*.md' -o -name '*.txt' -o -name '*.sh' -o \
     -name '*.cpp' -o -name '*.cc' -o -name '*.c' -o \
     -name '*.h' -o -name '*.hpp' -o -name '*.pro' -o \
     -name '*.html' -o -name 'Makefile' \) \
  ! -path '*/logs/*' \
  ! -path '*/.git/*' \
  -printf '%TY-%Tm-%Td %TH:%TM:%TS  %10s  %p\n' 2>/dev/null |
sort >&3

section "DATA INVENTORY ONLY -- RAW CSV/JSONL CONTENTS OMITTED"

if [[ -d "${ROOT}/data" ]]; then
  printf 'CSV file count: ' >&3
  find "${ROOT}/data" -maxdepth 1 -type f -name '*.csv' | wc -l >&3

  printf 'JSONL file count: ' >&3
  find "${ROOT}/data" -maxdepth 1 -type f -name '*.jsonl' | wc -l >&3

  printf '\nNewest 40 data filenames:\n' >&3

  find "${ROOT}/data" -maxdepth 1 -type f \
    \( -name '*.csv' -o -name '*.jsonl' \) \
    -printf '%T@ %TY-%Tm-%Td %TH:%TM:%TS %s %f\n' 2>/dev/null |
  sort -nr |
  head -40 |
  cut -d' ' -f2- >&3
fi

section "CSV ANALYZER DISCOVERY REFERENCES"

if (( ${#ANALYZER_REFERENCES[@]} == 0 )); then
  printf 'No text/source references found for AIH_V5_CSV_AGGREGATE_LATEST.html\n' >&3
else
  for f in "${ANALYZER_REFERENCES[@]}"; do
    printf '%s\n' "$f" >&3
  done
fi

# Highest-priority current documentation.
emit_file "${ROOT}/AIH_V5_PROJECT_GOALS.md"
emit_file "${ROOT}/AIH_V5_PROJECT_GOALS_20260811.md"
emit_file "${ROOT}/AIH_V5_IMPLEMENTATION_PLAN.md"
emit_file "${ROOT}/AIH_V5_IMPLEMENTATION_PLAN_20260811.md"
emit_file "${ROOT}/README.md"

# Current HTML summaries.
emit_file "$CANONICAL_CSV_HTML"
emit_file "$DATED_CSV_HTML"
emit_file "${ROOT}/AIH_V5_REGISTRATION_AGGREGATE_LATEST.html"

# Main runtime control logic.
emit_file "${ROOT}/aih_v5.sh"

# Analyzer / generator / C/C++/Qt source.
if [[ -d "${ROOT}/tools" ]]; then
  while IFS= read -r -d '' f; do
    emit_file "$f"
  done < <(
    find "${ROOT}/tools" -maxdepth 1 -type f \
      \( -name '*.sh' -o -name '*.cpp' -o -name '*.cc' -o \
         -name '*.c' -o -name '*.h' -o -name '*.hpp' -o \
         -name '*.pro' -o -name 'Makefile' \) \
      -print0 |
    sort -z
  )
fi

if [[ -d "${ROOT}/qwen_ollama_chess_qt" ]]; then
  while IFS= read -r -d '' f; do
    emit_file "$f"
  done < <(
    find "${ROOT}/qwen_ollama_chess_qt" -maxdepth 1 -type f \
      \( -name '*.cpp' -o -name '*.cc' -o -name '*.c' -o \
         -name '*.h' -o -name '*.hpp' -o -name '*.pro' -o \
         -name 'Makefile' \) \
      -print0 |
    sort -z
  )
fi

for f in "${ANALYZER_REFERENCES[@]}"; do
  case "$f" in
    "$ROOT"/aih_v5.sh|"$ROOT"/tools/*|"$ROOT"/qwen_ollama_chess_qt/*)
      ;;
    *)
      emit_file "$f"
      ;;
  esac
done

section "SOURCE ZIP CONTENT LIST"

unzip -Z1 "$SOURCE_ZIP_LATEST" >&3 2>/dev/null || true

section "END OF AIH V5 CHATGPT HANDOFF"

printf '%s\n' \
  'Paste this entire text file into the ChatGPT conversation for project "AIH v5 github content update".' >&3

exec 3>&-

###############################################################################
# 4. OPEN HANDOFF IN GEDIT
###############################################################################

say "Handoff file created"
printf '%s\n' "$SUMMARY"
printf '\nSize: '
du -h "$SUMMARY" | awk '{print $1}'

if command -v gedit >/dev/null 2>&1; then
  say "Opening handoff in gedit"
  nohup gedit "$SUMMARY" >/dev/null 2>&1 &
  disown || true
else
  warn "gedit is not installed or not in PATH."
  printf 'Open this file manually:\n%s\n' "$SUMMARY"
fi

printf '\nDONE\n\n'
printf 'Pasteable handoff file:\n%s\n\n' "$SUMMARY"
printf 'Source ZIP intended for GitHub:\n%s\n' "$SOURCE_ZIP_LATEST"
