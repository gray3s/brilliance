#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_COUNT="${1:-5}"

if ! [[ "$RUN_COUNT" =~ ^[1-9][0-9]*$ ]]; then
  echo "usage: $0 [positive-run-count]" >&2
  exit 2
fi

OUT_DIR="$ROOT_DIR/runs/aih_v5_random_repeat_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT_DIR"

echo "aih_v5_repeat: output directory: $OUT_DIR"
echo "aih_v5_repeat: run count: $RUN_COUNT"

for run_index in $(seq 1 "$RUN_COUNT"); do
  started="$(date +%Y%m%d_%H%M%S)"
  echo "aih_v5_repeat: starting run $run_index/$RUN_COUNT at $started"
  set +e
  "$ROOT_DIR/bin/aih_v5" --registration-random
  status=$?
  set -e
  ended="$(date +%Y%m%d_%H%M%S)"
  echo "aih_v5_repeat: finished run $run_index/$RUN_COUNT status=$status at $ended"

  if [[ -r "$ROOT_DIR/AIH_V5_REGISTRATION_STATUS.csv" ]]; then
    cp -a "$ROOT_DIR/AIH_V5_REGISTRATION_STATUS.csv" \
      "$OUT_DIR/registration_status_run_${run_index}_${started}_${ended}.csv"
  fi
  if [[ -r "$ROOT_DIR/AIH_V5_REGISTRATION_DIAGNOSTICS.log" ]]; then
    cp -a "$ROOT_DIR/AIH_V5_REGISTRATION_DIAGNOSTICS.log" \
      "$OUT_DIR/registration_diagnostics_run_${run_index}_${started}_${ended}.log"
  fi
  if [[ -r "$ROOT_DIR/AIH_V5_PRELIMINARY_RESULTS_20260810.html" ]]; then
    cp -a "$ROOT_DIR/AIH_V5_PRELIMINARY_RESULTS_20260810.html" \
      "$OUT_DIR/latest_html_run_${run_index}_${started}_${ended}.html"
  fi
  echo "$run_index,$started,$ended,$status" >> "$OUT_DIR/run_status.csv"
done

echo "aih_v5_repeat: complete."
echo "aih_v5_repeat: saved outputs in: $OUT_DIR"
