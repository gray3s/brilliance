#include <chrono>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cstdio>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <sys/wait.h>

namespace fs = std::filesystem;

static std::string timestamp() {
  auto now = std::chrono::system_clock::now();
  std::time_t t = std::chrono::system_clock::to_time_t(now);
  std::tm tm{};
  localtime_r(&t, &tm);
  std::ostringstream out;
  out << std::put_time(&tm, "%Y%m%d_%H%M%S");
  return out.str();
}

static fs::path project_root() {
  fs::path cwd = fs::current_path();
  if (fs::exists(cwd / "bin" / "aih_v5") && fs::exists(cwd / "aih_v5.sh")) return cwd;
  if (fs::exists(cwd.parent_path() / "bin" / "aih_v5") && fs::exists(cwd.parent_path() / "aih_v5.sh")) return cwd.parent_path();
  return cwd;
}

static void copy_if_exists(const fs::path& src, const fs::path& dst) {
  if (!fs::exists(src)) return;
  fs::create_directories(dst.parent_path());
  fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
}

static int shell_status(int raw) {
  if (WIFEXITED(raw)) return WEXITSTATUS(raw);
  if (WIFSIGNALED(raw)) return 128 + WTERMSIG(raw);
  return raw;
}

struct RegAggregate {
  int tested = 0;
  int pass = 0;
};

struct MoveTiming {
  double elapsed = 0.0;
  int attempts = 0;
};

static std::vector<std::string> split_csv_line(const std::string& line) {
  std::vector<std::string> fields;
  std::string cur;
  bool quote = false;
  for (char c : line) {
    if (c == '"') quote = !quote;
    else if (c == ',' && !quote) {
      fields.push_back(cur);
      cur.clear();
    } else {
      cur += c;
    }
  }
  fields.push_back(cur);
  return fields;
}

static std::string trim(std::string s) {
  while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) s.erase(s.begin());
  while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
  return s;
}

static std::string shell_quote(const fs::path& p) {
  std::string s = p.string();
  std::string out = "'";
  for (char c : s) {
    if (c == '\'') out += "'\\''";
    else out += c;
  }
  out += "'";
  return out;
}

static std::string shell_quote_string(const std::string& s) {
  std::string out = "'";
  for (char c : s) {
    if (c == '\'') out += "'\\''";
    else out += c;
  }
  out += "'";
  return out;
}

static void open_html_file(const fs::path& html) {
  std::string uri = "file://" + fs::absolute(html).string();
  std::string cmd = "firefox " + shell_quote_string(uri) + " >/dev/null 2>&1 &";
  int status = std::system(cmd.c_str());
  (void)status;
}

static void write_live_wrapper(const fs::path& wrapper, const fs::path& content) {
  fs::create_directories(wrapper.parent_path());
  std::ofstream html(wrapper);
  std::string content_uri = "file://" + fs::absolute(content).string();
  html << "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">\n";
  html << "<meta http-equiv=\"refresh\" content=\"2\">\n";
  html << "<title>AIH v5 live repeat summary</title>\n";
  html << "<style>html,body{margin:0;height:100%;font-family:Arial,sans-serif}"
       << ".bar{padding:.5rem .75rem;background:#1f2933;color:white;font-size:.9rem}"
       << "iframe{width:100%;height:calc(100vh - 2.2rem);border:0}</style></head><body>\n";
  html << "<div class=\"bar\">AIH v5 live per-run summary. This page refreshes every 2 seconds.</div>\n";
  html << "<iframe src=\"" << content_uri << "\"></iframe>\n";
  html << "</body></html>\n";
}

static void write_live_placeholder(const fs::path& content) {
  fs::create_directories(content.parent_path());
  std::ofstream html(content);
  html << "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
       << "<title>AIH v5 waiting</title>"
       << "<style>body{font-family:Arial,sans-serif;margin:2rem;color:#1f2933}</style>"
       << "</head><body><h1>AIH v5 repeat run starting</h1>"
       << "<p>Waiting for the first per-run summary.</p></body></html>\n";
}

static std::map<std::string, MoveTiming> read_move_timing(const fs::path& jsonl) {
  std::map<std::string, MoveTiming> timings;
  if (!fs::exists(jsonl)) return timings;
  std::string cmd =
    "jq -r '.events[]? | select(.model != null and .model != \"harness\") | "
    "[.model, (.move_to_referee_elapsed_s // .response.elapsed_s // .original_response.elapsed_s // empty)] | @tsv' " +
    shell_quote(jsonl);
  FILE* pipe = popen(cmd.c_str(), "r");
  if (!pipe) return timings;
  char buf[4096];
  while (fgets(buf, sizeof(buf), pipe)) {
    std::string line(buf);
    while (!line.empty() && (line.back() == '\n' || line.back() == '\r')) line.pop_back();
    size_t tab = line.find('\t');
    if (tab == std::string::npos) continue;
    std::string agent = trim(line.substr(0, tab));
    std::string value = trim(line.substr(tab + 1));
    if (agent.empty() || value.empty()) continue;
    try {
      double seconds = std::stod(value);
      auto& timing = timings[agent];
      timing.elapsed += seconds;
      timing.attempts++;
    } catch (...) {
    }
  }
  pclose(pipe);
  return timings;
}

static void write_registration_snapshot_with_move_timing(const fs::path& src, const fs::path& dst, const fs::path& jsonl) {
  if (!fs::exists(src)) return;
  auto timings = read_move_timing(jsonl);
  fs::create_directories(dst.parent_path());
  std::ifstream in(src);
  std::ofstream out(dst);
  if (!in || !out) return;
  std::string line;
  if (std::getline(in, line)) {
    out << line << ",avg_move_seconds,move_attempts\n";
  }
  char num[64];
  while (std::getline(in, line)) {
    auto fields = split_csv_line(line);
    std::string agent = fields.empty() ? "" : trim(fields[0]);
    auto it = timings.find(agent);
    if (it != timings.end() && it->second.attempts > 0) {
      double avg = it->second.elapsed / it->second.attempts;
      std::snprintf(num, sizeof(num), "%.3f", avg);
      out << line << "," << num << "," << it->second.attempts << "\n";
    } else {
      out << line << ",,0\n";
    }
  }
}

static std::map<std::string, RegAggregate> read_registration_aggregate(const fs::path& repeat_dir) {
  std::map<std::string, RegAggregate> agents;
  if (!fs::exists(repeat_dir)) return agents;
  std::vector<fs::path> csvs;
  for (const auto& ent : fs::directory_iterator(repeat_dir)) {
    if (!ent.is_regular_file()) continue;
    std::string name = ent.path().filename().string();
    if (name.rfind("registration_status_run_", 0) == 0 && ent.path().extension() == ".csv") {
      csvs.push_back(ent.path());
    }
  }
  std::sort(csvs.begin(), csvs.end());
  for (const auto& csv : csvs) {
    std::ifstream in(csv);
    if (!in) continue;
    std::string line;
    std::getline(in, line);
    while (std::getline(in, line)) {
      auto fields = split_csv_line(line);
      if (fields.size() < 2) continue;
      std::string agent = trim(fields[0]);
      std::string status = trim(fields[1]);
      if (agent.empty()) continue;
      auto& agg = agents[agent];
      agg.tested++;
      if (status == "pass") agg.pass++;
    }
  }
  return agents;
}

static bool minregs_satisfied(const fs::path& repeat_dir, int minregs) {
  auto agents = read_registration_aggregate(repeat_dir);
  if (agents.empty()) return false;
  for (const auto& [agent, agg] : agents) {
    (void)agent;
    if (agg.pass < minregs) return false;
  }
  return true;
}

int main(int argc, char** argv) {
  int run_count = 5;
  int minregs = 0;
  std::vector<std::string> extra_args;
  for (int i = 1; i < argc; ++i) {
    std::string arg = argv[i];
    if (arg.rfind("--nruns=", 0) == 0 || arg.rfind("--n-runs=", 0) == 0 || arg.rfind("--runs=", 0) == 0) {
      auto pos = arg.find('=');
      run_count = std::stoi(arg.substr(pos + 1));
      continue;
    }
    if (arg.rfind("--minregs=", 0) == 0 || arg.rfind("--min-regs=", 0) == 0 || arg.rfind("--minimum-registrations=", 0) == 0) {
      auto pos = arg.find('=');
      minregs = std::stoi(arg.substr(pos + 1));
      continue;
    }
    if (i == 1) {
      try {
        run_count = std::stoi(arg);
        continue;
      } catch (...) {
        // normal aih_v5 argument
      }
    }
    extra_args.push_back(arg);
  }
  if (run_count < 1) {
    std::cerr << "usage: aih_v5_repeat [--nruns=N] [--minregs=N] [aih_v5 args...]\n";
    return 2;
  }
  if (minregs < 0) {
    std::cerr << "usage: aih_v5_repeat [--nruns=N] [--minregs=N] [aih_v5 args...]\n";
    return 2;
  }

  fs::path root = project_root();
  fs::current_path(root);
  fs::path out_dir = root / "runs" / ("aih_v5_random_repeat_" + timestamp());
  fs::create_directories(out_dir);
  fs::path live_content = out_dir / "AIH_V5_REPEAT_LIVE_CURRENT_RUN.html";
  fs::path live_wrapper = out_dir / "AIH_V5_REPEAT_LIVE_VIEWER.html";
  write_live_placeholder(live_content);
  write_live_wrapper(live_wrapper, live_content);

  if (extra_args.empty()) extra_args.push_back("--registration-random");

  std::ofstream status_csv(out_dir / "run_status.csv");
  status_csv << "run_index,started,ended,status,command\n";

  std::cout << "aih_v5_repeat: output directory: " << out_dir << "\n";
  std::cout << "aih_v5_repeat: live per-run html: " << live_wrapper << "\n";
  open_html_file(live_wrapper);
  if (minregs > 0) {
    std::cout << "aih_v5_repeat: min registrations target: " << minregs << "\n";
  } else {
    std::cout << "aih_v5_repeat: run count: " << run_count << "\n";
  }

  int final_status = 0;
  for (int run = 1; minregs > 0 || run <= run_count; ++run) {
    std::string started = timestamp();
    std::ostringstream cmd;
    cmd << "AIH_V5_REPEAT_RUN_INDEX=" << run << " ";
    if (minregs > 0) {
      cmd << "AIH_V5_REPEAT_MINREGS=" << minregs << " ";
    } else {
      cmd << "AIH_V5_REPEAT_RUN_COUNT=" << run_count << " ";
    }
    cmd << "AIH_V5_OPEN_HTML_REPORT=0 AIH_V5_REPEAT_LIVE_HTML=" << shell_quote(live_content)
        << " ./bin/aih_v5 --nruns=1";
    for (const auto& arg : extra_args) cmd << " " << arg;

    if (minregs > 0) {
      std::cout << "aih_v5_repeat: starting run " << run << " for minregs=" << minregs << " at " << started << "\n";
    } else {
      std::cout << "aih_v5_repeat: starting run " << run << "/" << run_count << " at " << started << "\n";
    }
    int raw = std::system(cmd.str().c_str());
    int status = shell_status(raw);
    if (status != 0 && final_status == 0) final_status = status;
    std::string ended = timestamp();
    if (minregs > 0) {
      std::cout << "aih_v5_repeat: finished run " << run << " for minregs=" << minregs << " status=" << status << " at " << ended << "\n";
    } else {
      std::cout << "aih_v5_repeat: finished run " << run << "/" << run_count << " status=" << status << " at " << ended << "\n";
    }

    write_registration_snapshot_with_move_timing(
      root / "AIH_V5_REGISTRATION_STATUS.csv",
      out_dir / ("registration_status_run_" + std::to_string(run) + "_" + started + "_" + ended + ".csv"),
      root / "data" / "AIH_V5_CURRENT_RUN_AGGREGATE.jsonl");
    copy_if_exists(root / "AIH_V5_REGISTRATION_DIAGNOSTICS.log",
                   out_dir / ("registration_diagnostics_run_" + std::to_string(run) + "_" + started + "_" + ended + ".log"));
    copy_if_exists(root / "AIH_V5_PRELIMINARY_RESULTS_20260810.html",
                   out_dir / ("latest_html_run_" + std::to_string(run) + "_" + started + "_" + ended + ".html"));
    status_csv << run << "," << started << "," << ended << "," << status << ",\"" << cmd.str() << "\"\n";
    status_csv.flush();
    if (minregs > 0 && minregs_satisfied(out_dir, minregs)) {
      std::cout << "aih_v5_repeat: minregs satisfied after run " << run << ": every tested agent has at least " << minregs << " registration pass(es)\n";
      break;
    }
  }

  status_csv.close();
  fs::path aggregate_bin = root / "bin" / "aih_v5_repeat_html";
  if (fs::exists(aggregate_bin)) {
    std::ostringstream aggregate_cmd;
    aggregate_cmd << "./bin/aih_v5_repeat_html ";
    if (minregs > 0) aggregate_cmd << "--nruns=" << minregs << " ";
    aggregate_cmd << out_dir.string();
    std::cout << "aih_v5_repeat: generating aggregate html...\n";
    int aggregate_status = shell_status(std::system(aggregate_cmd.str().c_str()));
    std::cout << "aih_v5_repeat: aggregate html status=" << aggregate_status << "\n";
    if (aggregate_status != 0 && final_status == 0) final_status = aggregate_status;
  } else {
    std::cout << "aih_v5_repeat: aggregate binary not found: " << aggregate_bin << "\n";
  }
  std::cout << "aih_v5_repeat: complete.\n";
  std::cout << "aih_v5_repeat: saved outputs in: " << out_dir << "\n";
  return final_status;
}
