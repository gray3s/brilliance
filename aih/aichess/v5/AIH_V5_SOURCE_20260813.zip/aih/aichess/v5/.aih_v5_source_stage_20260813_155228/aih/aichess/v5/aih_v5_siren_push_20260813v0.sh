#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="/home/sag/RPA2/myLLC/AI/brilliance"
V5_REL="aih/aichess/v5"
V5_DIR="${REPO_ROOT}/${V5_REL}"
PUBLISHED_DIR="${V5_DIR}/published_results"
BRANCH="main"
REMOTE_BLOB_BASE="https://github.com/gray3s/brilliance/blob/${BRANCH}"
HTMLPREVIEW_BASE="https://htmlpreview.github.io/?${REMOTE_BLOB_BASE}"
SIREN_HTML="${PUBLISHED_DIR}/AIH_V5_SIREN_CSV_AGGREGATE_LATEST.html"
COMMIT_MESSAGE="Publish AIH v5 Siren aggregate artifact"

cd "${V5_DIR}"

echo "[aih-v5-siren-push] publishing AIH v5/Siren public artifact only"
echo "[aih-v5-siren-push] Siren code is intentionally excluded"

if [[ ! -r "${SIREN_HTML}" ]]; then
  echo "[aih-v5-siren-push] missing Siren aggregate HTML: ${SIREN_HTML}" >&2
  echo "[aih-v5-siren-push] run the future AIH v5/Siren CSV processor first" >&2
  exit 2
fi

relpaths=(
  "${V5_REL}/published_results/AIH_V5_SIREN_CSV_AGGREGATE_LATEST.html"
)

cd "${REPO_ROOT}"

current_branch="$(git branch --show-current)"
if [[ "${current_branch}" != "${BRANCH}" ]]; then
  echo "[aih-v5-siren-push] refusing to push from branch '${current_branch}', expected '${BRANCH}'" >&2
  exit 2
fi

echo
echo "[aih-v5-siren-push] link for AIH v5 Siren LinkedIn post:"
echo "  ${HTMLPREVIEW_BASE}/${V5_REL}/published_results/AIH_V5_SIREN_CSV_AGGREGATE_LATEST.html"

echo
echo "[aih-v5-siren-push] git status before staging:"
git status --short -- "${relpaths[@]}"

echo
echo "[aih-v5-siren-push] staging exact AIH v5/Siren public artifact"
git add -- "${relpaths[@]}"

if git diff --cached --quiet -- "${relpaths[@]}"; then
  echo "[aih-v5-siren-push] no staged changes; nothing to commit or push"
  exit 0
fi

echo "[aih-v5-siren-push] committing"
git commit -m "${COMMIT_MESSAGE}" -- "${relpaths[@]}"

echo "[aih-v5-siren-push] pushing origin/${BRANCH}"
git push origin "${BRANCH}"

echo
echo "[aih-v5-siren-push] pushed AIH v5/Siren public artifact"
