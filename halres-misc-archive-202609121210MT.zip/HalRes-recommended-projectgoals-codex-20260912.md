HalRes project goals modification ideas - temporary holding file
Created: 2026-09-12

Purpose:
Record any additional HalRes project-goals modification ideas here for later
review and resolution. Do not treat entries in this file as approved project
goals until they are explicitly incorporated into the main HalRes project goals
document and the associated halres/misc archive zip file is refreshed.

Pending ideas:

