20260912 1115MT
HallucinationResolution (HalRes) project

This project-goals document is organized by development dependencies. Version
numbers identify the intended order of work. If later project decisions change
the dependency graph, the version sequence should be updated to match the
actual order of implementation and comparison.

Agent-specific HalRes outputs remain under:

~/RPA2/devneutral/halres/gpt
~/RPA2/devneutral/halres/codex

The canonical HalRes project-goals file is controlled by the user. GPT and
Codex may maintain their own recommended-project-goals documents and propose
changes, but neither agent should independently treat its own recommendations
as adopted project requirements without explicit user authorization.

for v0 - original HalRes algorithm definition:

Preserve the user's original HalRes concept as the authoritative algorithmic
objective. The v0 work defines the transformation from English-language input
to a 2D state-space map, including bounded decision/state transitions and the
relationship among prior state, admissible evidence, applicable rule or
decision criterion, decision/branch, resulting state, output/next-state
pointer, and unresolved state.

GPT and Codex may independently formalize this concept, but neither agent's
formalization automatically becomes the canonical algorithm. The goal of v0 is
to produce and review an algorithm until it passes a 2D state-space map logical
review.

for v1 - independent GPT and Codex implementations:

GPT independently implements the original user-defined HalRes algorithm.
Codex independently implements the original user-defined HalRes algorithm.

The implementations may use different internal architectures and
representations. Both must provide sufficient outputs to map their results into
the common logical comparison contract defined in v2. Neither implementation
should be modified after seeing the other agent's baseline results until the
baseline comparison has been preserved.

for v2 - shared test corpus and comparison protocol:

Create and freeze a shared test package containing:

- the exact English-language input corpus;
- prompt/source provenance;
- corpus revision/hash;
- run protocol;
- minimum common logical comparison fields;
- execution-provenance requirements;
- judging/comparison procedure.

Corpus provenance should distinguish at least:

- H - primarily human-origin;
- GPT - primarily GPT-origin;
- CODEX - primarily Codex-origin;
- MIXED - materially produced by more than one source.

The corpus must be shared, frozen before either agent creates its own baseline
output, identical for GPT and Codex, and not modified in response to the first
baseline results. Comparison reports should show results by corpus provenance
class so prompt-source bias remains visible.

The common logical comparison contract must recover at least:

- source material;
- prior state;
- evidence used;
- applicable rule or decision criterion;
- decision/branch;
- resulting state;
- output/next-state pointer;
- unresolved or failure status;
- provenance.

The baseline execution contract must record at least:

- implementation revision/hash;
- model filename/name and hash where applicable;
- llama.cpp version/commit where applicable;
- relevant model/runtime parameters;
- timeout/retry policy;
- seed where applicable;
- elapsed time;
- failure/retry outcome;
- run ID and timestamps.

Internal schemas may remain agent-specific, but each implementation must export
or map its results into comparable logical and baseline-execution objects.

for v3 - independent baseline creation and static cross-check:

Before either agent receives the other agent's baseline output, freeze:

- GPT implementation revision/hash;
- Codex implementation revision/hash;
- corpus revision/hash;
- run protocol;
- common comparison mapping.

Then:

1. Each agent creates its own baseline output independently, if execution is
   part of that agent's implementation.
2. Preserve both baseline result sets immutably.
3. Each agent independently performs a static cross-check of the other agent's
   v0 algorithm description, implementation source, build artifacts, and
   expected output contract.
4. Compare the static cross-check reports and mapped expected-output contracts.
5. Classify every significant disagreement.

For v3, "cross-check" means inspection and review of the other agent's
algorithm, code, build artifacts, and expected outputs. It does not mean that
one agent should execute the other agent's implementation as the primary
cross-check. Reciprocal execution may be used later as a separate
reproducibility diagnostic only when explicitly requested, and its results must
not replace either agent's own preserved baseline output.

Baseline outputs are never overwritten. Baseline implementation hashes are
retained. Corrected implementations receive new revisions. Rerun outputs
receive new run IDs.

Difference classifications should include, where applicable:

- GPT implementation defect;
- Codex implementation defect;
- ambiguity in the original HalRes algorithm;
- ambiguity or defect in the test corpus;
- inadequate comparison mapping;
- local-model/runtime variation;
- legitimate implementation difference with equivalent logical result;
- unresolved difference.

Corrections should occur only after the baseline comparison has been preserved
and disagreements have been classified.

pre-FlowiseCPP checkpoint:

STOP:
No custom FlowiseCPP architecture, design, GUI/controller design,
implementation, or modification may begin until the required original HalRes
implementation baseline and cross-comparison have been completed and preserved.

This checkpoint does not prohibit:

- reading Flowise or FlowisePy;
- provenance research;
- historical analysis;
- extraction of architectural lessons;
- documentation of Flowise failure modes or useful concepts;
- comparison of archived/current Flowise design choices.

It does prohibit using that work to begin custom FlowiseCPP architecture,
design, implementation, GUI/controller work, or HalRes adaptation specifically
for FlowiseCPP before the HalRes algorithm baseline has been established.

for v4 - optional alternative HalRes implementations / algorithms:

After the original HalRes baseline exists, GPT and Codex may develop:

- alternative implementations of the original HalRes algorithm; and/or
- materially different alternative algorithms intended to produce the same
  HalRes result.

These must be explicitly labelled. An alternative algorithm must never be
presented as merely another revision of the original algorithm.

Each branch carried forward should have:

- runnable headless prototype;
- source;
- build/run instructions;
- algorithm lineage;
- input/output examples;
- logical validation;
- comparison against the original baseline.

HalRes-specific GUI work may be added after a branch has a preserved headless
baseline. Any HalRes GUI must remain distinguishable from later FlowiseCPP
GUI/controller development.

for v5 - cross-algorithm / cross-implementation HalRes comparison:

Compare:

- GPT original vs Codex original;
- alternative implementation vs original implementation;
- alternative algorithm vs original algorithm;
- GPT alternative vs Codex alternative where comparable;
- headless vs GUI-assisted behavior where applicable.

Do not collapse distinct algorithm branches until their differences have been
documented and compared.

for v6 - Flowise / FlowisePy provenance and FlowiseCPP requirements:

Use the preserved Flowise/FlowisePy material to:

- extract requirements;
- extract workflow/state-management concepts;
- document historical design choices;
- document failure/sunset cautions;
- decide what should and should not be inherited conceptually.

This stage should produce FlowiseCPP requirements and design inputs, but it
does not itself authorize FlowiseCPP architecture, design, implementation, or
GUI/controller development before the pre-FlowiseCPP checkpoint is satisfied.

Shared local Flowise provenance repositories:

~/RPA2/devneutral/flowise/FlowisePy
local clone of https://github.com/FlowiseAI/FlowisePy
aka archived flowise

~/RPA2/devneutral/flowise/Flowise
local clone of https://github.com/FlowiseAI/Flowise
aka current/reference flowise

Additional Flowise source references may be stored under:

~/RPA2/devneutral/flowise/discussions
~/RPA2/devneutral/flowise/sunset

Pinned shared reference material as of 2026-09-12:

Both GPT and Codex should work from the same reference set until a later
explicit HalRes reference update changes it.

- Archived Flowise/FlowisePy reference:
  https://github.com/FlowiseAI/FlowisePy
  pinned commit: e679154c6bb0432ab026e8904223e30bfa1cef4e
  commit date: 2024-09-23T12:55:34Z
  commit note: add api_key to constructor

- Current/reference Flowise repository:
  https://github.com/FlowiseAI/Flowise
  pinned commit: 9291856d1ea4a4ceea9f8fef8ce14f4f6c81e8eb
  commit date: 2026-08-13T12:38:19Z
  commit note: Update README.md (#6728)

- Shared HalRes misc archive on GitHub:
  https://github.com/gray3s/brilliance/blob/main/halres-misc-archive-202609121210MT.zip

The GitHub ZIP filename is a mutable latest-reference convenience. Serious
comparative runs must record the exact Git commit SHA and ZIP SHA256 used.

Existing FlowiseCPP work created before the pre-FlowiseCPP checkpoint should
be labelled:

pre-gate artifact produced under earlier HalRes ordering

Such work is preserved for reference. It should not influence the independent
HalRes baseline comparison and should not automatically count as completion of
any reordered stage.

for v7 - custom FlowiseCPP design and implementation:

Only after the pre-FlowiseCPP checkpoint has been satisfied:

- design the custom FlowiseCPP architecture;
- develop the local-native controller/runtime;
- implement the appropriate GUI/controller;
- integrate the selected HalRes algorithm/interface;
- preserve local llama.cpp/GGUF-only constraints where applicable;
- preserve provenance from the selected HalRes implementation lineage.

The custom FlowiseCPP build is not an attempt to duplicate the archived
Flowise/FlowisePy application's full range of functionality. The archived and
current Flowise repositories are provenance and design-reference inputs only.

The custom build target is a deliberately narrower local-native workflow
controller/editor/runtime with Ubuntu 24 as the OS baseline, bare-metal
deployment with no Docker, Docker-based services, Snap, or Docker-like services
that attempt to provide build configuration lock-in for Ubuntu applications or
enhance hardware/OS security through third-party confinement/sandboxing means.
The intended security baseline is normal Linux physical, login/rlogin, network,
and firewall protection only. The build should use local storage and local
model execution limited to llama.cpp-backed local GGUF models. Docker,
Docker-based services, Snap/Snapcraft-style packaging lock-in, Docker-like
Ubuntu application build lock-in services, third-party hardware/OS-security
confinement layers, cloud models, managed services, and broad Flowise
integration parity are out of scope unless a later explicit HalRes decision
changes that rule.

The existing local Codex-side flowisecpp v0 build/source tree is available as a
comparison and cautionary/reference implementation, not as the default baseline:

~/RPA2/codex/flowisecpp

The current GPT intake/provenance snapshot for that existing local flowisecpp
tree is under:

~/RPA2/devneutral/halres/gpt/v4-intake/20260912_122915_MDT

Agents may inspect that local flowisecpp tree and snapshot to understand prior
implementation choices, risks, and omissions. They should not assume that tree
resolves the HalRes FlowiseCPP starting point. Any reuse of existing Codex
flowisecpp code, any use of GPT pre-gate FlowiseCPP work, or any direct porting
from archived Flowise source must be called out explicitly as a separate
decision.

FlowiseCPP does not have to be only cpp/qt, but python code should not be part
of the custom build. Any non-cpp/qt support must still preserve the Ubuntu 24,
no-Docker/no-Docker-based-services/no-Snap/no-Docker-like-build-lock-in-services,
no-third-party-security-confinement-services, local llama.cpp/GGUF-only scope
boundary.

These will be custom prototype builds of FlowiseCPP, not production-targeted
builds.

for v8 - FlowiseCPP testing and GPT/Codex comparison:

Use a defined test protocol to evaluate the GPT and Codex FlowiseCPP
implementations.

Compare:

- architecture;
- HalRes integration;
- workflow/state behavior;
- failure handling;
- model/runtime behavior;
- resource behavior;
- GUI/controller behavior;
- provenance and reproducibility;
- conformance to project constraints.

for v9 - downstream application testing:

Use the resulting architecture in downstream test projects, such as chess or
other bounded applications, to determine whether the complete HalRes +
FlowiseCPP development process produces useful and auditable systems.

global configuration-control rule:

Every serious HalRes comparative run should record:

- canonical project-goals revision/hash;
- exact Git commit SHA for shared reference material;
- shared ZIP SHA256 where applicable;
- corpus revision/hash;
- GPT or Codex implementation revision/hash;
- model filename and hash where applicable;
- llama.cpp version/commit where applicable;
- relevant model/runtime parameters;
- retry/timeout rules;
- seed where applicable;
- run ID;
- timestamps;
- output-artifact hashes.

A mutable GitHub filename may be used as a convenient latest reference, but it
must not be treated as sufficient run provenance.
