20260912 1115MT
HallucinationResolution (HalRes) project

for v0:

Have both gpt and codex develop their own customised hallucination resolution algorithm 
based on the transformation from English language to a 2D state-space map. 

For the v0 build the goal is to produce an algorithm to do this and review it with the algorithm, 
repeating until the algorithm passes a 2D state-space map logical review. 

For v1:
we will have each agent attempt to design and build a custom controller in cpp+qt5 on bare-iron Ubuntu 24
that will take-in a set of english-language text files and map the set to a 2d state-space map 
and analyze the map logically using the algorithm developed in v0. 

For the time being this will be done in agent-specific subfolders under 
~/RPA2/devneutral/halres i.e. "gpt" and "codex".

for v2: 
Each agent will be tasked to develop a custom "judging" build that will take the custom v1 output 
from each agent and compare, contrast and "grade" the results.

for v3:
Each agent will judge the flowise project notes at the following github links:
https://github.com/FlowiseAI/FlowisePy (aka "archived flowise")
https://github.com/FlowiseAI/Flowise/discussions/6727 (aka "flowise future #6726")
https://flowiseai.com/sunset (aka "flowise discussion board summary")
in 3 separate "analysis" documents

Shared local Flowise provenance repositories:

~/RPA2/devneutral/flowise/FlowisePy
local clone of https://github.com/FlowiseAI/FlowisePy
aka archived flowise
primary archived-flowise provenance source for v3 analysis and for extracting
requirements, concepts, and cautions for the v4 custom flowisecpp design/build
track

~/RPA2/devneutral/flowise/Flowise
local clone of https://github.com/FlowiseAI/Flowise
aka current/reference flowise
current/reference Flowise provenance source for v3 analysis and for comparing
the archived-flowise direction against later Flowise project direction

Additional Flowise v3 source references may be stored under:

~/RPA2/devneutral/flowise/discussions
~/RPA2/devneutral/flowise/sunset

The shared local Flowise repositories under ~/RPA2/devneutral/flowise are the
provenance basis for the Flowise side of HalRes, not direct implementation
bases. Agents should not clone a second copy of the archived/current Flowise
repositories, should not install dependencies, and should not build those
upstream repositories unless explicitly requested. For normal HalRes v3 work,
inspect only the narrow documentation and source files needed for the three
analysis documents. For v4 custom flowisecpp work, use the archived
Flowise/FlowisePy provenance to extract requirements, design lessons, node and
workflow concepts, and failure/sunset cautions. Do not directly fork, port, or
mechanically translate the archived Flowise repository into the v4/v1 custom
flowisecpp build unless a later explicit decision changes this rule.

Agent-specific HalRes outputs remain under:

~/RPA2/devneutral/halres/gpt
~/RPA2/devneutral/halres/codex


for v4:
Each agent will start from the requirements, concepts, and cautions extracted
from the archived Flowise/FlowisePy provenance identified in v3 and consider
those in the context of v0 through v3 above.

The existing local Codex-side flowisecpp v0 build/source tree is available as a
comparison and cautionary/reference implementation, not as the default v4
baseline:

~/RPA2/codex/flowisecpp

The current GPT intake/provenance snapshot for that existing local flowisecpp
tree is under:

~/RPA2/devneutral/halres/gpt/v4-intake/20260912_122915_MDT

Agents may inspect that local flowisecpp tree and snapshot to understand prior
Codex implementation choices, risks, and omissions. They should not assume that
tree resolves the HalRes v4 starting point. The v4 custom flowisecpp build
should be derived from the archived/current Flowise provenance findings and the
HalRes v0-v3 analysis products, not by direct inheritance from either the
archived Flowise GitHub repository or the existing Codex flowisecpp code. Any
reuse of existing Codex flowisecpp code, or any direct porting from archived
Flowise source, must be called out explicitly as a separate decision.

Then generate an analysis file of comments, criticisms and recommendations for a custom 
flowisecpp v1 build that will be agentic AI specific. I.e. create a custom 
~/RPA2/<agent>/flowisecpp/v1 build folder
with the specific rules that it will not involve Python at all 
(all python code is to be translated into cpp and/or qt)
and custom-build the v3 products into v4 to run on bare iron ubuntu 24, it will not involve Docker. 

For the time being we will leave any specific Docker-related or Docker-dependent features out of the custom v4 builds. 
These will be custom prototype builds of flowisecpp, not production-targeted build. 

flowisecpp doesn't have to be ONLY cpp/qt, just use cpp/qt to replace the python code.
 
The goal of v4 will be to see if the v3 development process is sufficient to build custom v4 builds 

for v5: 
we will use the v3 custom test protocols to analyze the custom v4 builds
and comment appropriately based on the examples in the above versions. 

for v6:

each agent should design and build a custom test project (potentially ai<agent>chessplay v3r1b1)
and evaluate it using v3 and comment appropriately based on the examples in the above versions. 
