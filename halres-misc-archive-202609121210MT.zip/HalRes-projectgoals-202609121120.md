20260912 1115MT
HallucinationResolution (HalRes) project

for v0:

Have both gpt and codex develop their own customised hallucination resolution algorithm 
based on the transformation from English language to a 2D state-space map. 

For the v0 build the goal is to produce an algorithm to do this and review it with the algorithm, 
repeating until the algorithm passes a 2D state-space map logical review. 

For v1:
we will have each agent attempt to design and build a custom controller in cpp+qt5 on bare-iron Ubuntu 24
that will take-in a set of english-language text files and map the set to a 2d state-space map 
and analyze the map logically using the algorithm developed in v0. 

For the time being this will be done in agent-specific subfolders under 
~/RPA2/devneutral/halres i.e. "gpt" and "codex".

for v2: 
Each agent will be tasked to develop a custom "judging" build that will take the custom v1 output 
from each agent and compare, contrast and "grade" the results.

for v3:
Each agent will judge the flowise project notes at the following github linkx:
https://github.com/FlowiseAI/FlowisePy (aka "archived flowise")
https://github.com/FlowiseAI/Flowise/discussions/6727 (aka "flowise future #6726")
https://flowiseai.com/sunset (aka "flowise discussion board summary")
in 3 separate "analysis" documents

Shared local Flowise reference repositories:

~/RPA2/devneutral/flowise/FlowisePy
local clone of https://github.com/FlowiseAI/FlowisePy
aka archived flowise

~/RPA2/devneutral/flowise/Flowise
local clone of https://github.com/FlowiseAI/Flowise
aka current/reference flowise

Additional Flowise v3 source references may be stored under:

~/RPA2/devneutral/flowise/discussions
~/RPA2/devneutral/flowise/sunset

Agent-specific HalRes outputs remain under:

~/RPA2/devneutral/halres/gpt
~/RPA2/devneutral/halres/codex


for v4:
Each agent will consider the 
flowisecpp v0 build currently in the ~/RPA2/codex tree in the context of v0 through v3 above. 
Then generate an analysis file of comments, criticisms and recommendations for a custom 
flowisecpp v1 build that will be agentic AI specific. I.e. create a custom 
~/RPA2/<agent>/flowisecpp/v1 build folder
with the specific rules that it will not involve Python at all 
(all python code is to be translated into cpp and/or qt)
and custom-build the v3 products into v4 to run on bare iron ubuntu 24, it will not involve Docker. 

For the time being we will leave any specific Docker-related or Docker-dependent features out of the custom v4 builds. 
These will be custom prototype builds of flowisecpp, not production-targeted build. 

flowisecpp doesn't have to be ONLY cpp/qt, just use cpp/qt to replace the python code.
 
The goal of v4 will be to see if the v3 development process is sufficient to build custom v4 builds 

for v5: 
we will use the v3 custom test protocols to analyze the custom v4 builds
and comment appropriately based on the examples in the above versions. 

for v6:

each agent should design and build a custom test project (potentially ai<agent>chessplay v3r1b1)
and evaluate it using v3 and comment appropriately based on the examples in the above versions. 
