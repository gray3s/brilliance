# HalRes Recommended Project-Goals List — GPT

Status: NONCANONICAL / FOR USER CONSIDERATION

Intended local destination:
`~/RPA2/devneutral/halres/misc/`

This document reproduces the current user-provided HalRes project goals for
context, followed by a separate GPT-recommended addendum. The reproduced
canonical text below is not modified by GPT.

---

# Current User-Provided Project Goals (Reference Copy)

20260912 1115MT
HallucinationResolution (HalRes) project

for v0:

Have both gpt and codex develop their own customised hallucination resolution algorithm 
based on the transformation from English language to a 2D state-space map. 

For the v0 build the goal is to produce an algorithm to do this and review it with the algorithm, 
repeating until the algorithm passes a 2D state-space map logical review. 

For v1:
we will have each agent attempt to design and build a custom controller in cpp+qt5 on bare-iron Ubuntu 24
that will take-in a set of english-language text files and map the set to a 2d state-space map 
and analyze the map logically using the algorithm developed in v0. 

For the time being this will be done in agent-specific subfolders under 
~/RPA2/devneutral/halres i.e. "gpt" and "codex".

for v2: 
Each agent will be tasked to develop a custom "judging" build that will take the custom v1 output 
from each agent and compare, contrast and "grade" the results.

for v3:
Each agent will judge the flowise project notes at the following github links:
https://github.com/FlowiseAI/FlowisePy (aka "archived flowise")
https://github.com/FlowiseAI/Flowise/discussions/6727 (aka "flowise future #6726")
https://flowiseai.com/sunset (aka "flowise discussion board summary")
in 3 separate "analysis" documents

Shared local Flowise provenance repositories:

~/RPA2/devneutral/flowise/FlowisePy
local clone of https://github.com/FlowiseAI/FlowisePy
aka archived flowise
primary archived-flowise provenance source for v3 analysis and for extracting
requirements, concepts, and cautions for the v4 custom flowisecpp design/build
track

~/RPA2/devneutral/flowise/Flowise
local clone of https://github.com/FlowiseAI/Flowise
aka current/reference flowise
current/reference Flowise provenance source for v3 analysis and for comparing
the archived-flowise direction against later Flowise project direction

Additional Flowise v3 source references may be stored under:

~/RPA2/devneutral/flowise/discussions
~/RPA2/devneutral/flowise/sunset

Pinned shared reference material as of 2026-09-12:

Both GPT and Codex should work from the same reference set until a later
explicit HalRes reference update changes it.

- Archived Flowise/FlowisePy reference:
  https://github.com/FlowiseAI/FlowisePy
  pinned commit: e679154c6bb0432ab026e8904223e30bfa1cef4e
  commit date: 2024-09-23T12:55:34Z
  commit note: add api_key to constructor

- Current/reference Flowise repository:
  https://github.com/FlowiseAI/Flowise
  pinned commit: 9291856d1ea4a4ceea9f8fef8ce14f4f6c81e8eb
  commit date: 2026-08-13T12:38:19Z
  commit note: Update README.md (#6728)

- Shared HalRes misc archive on GitHub:
  https://github.com/gray3s/brilliance/blob/main/halres-misc-archive-202609121210MT.zip
  pinned commit: 7e09190b9e36a268844c4881ab8160c93262d8ff
  pinned blob URL:
  https://github.com/gray3s/brilliance/blob/7e09190b9e36a268844c4881ab8160c93262d8ff/halres-misc-archive-202609121210MT.zip
  pinned raw URL:
  https://github.com/gray3s/brilliance/raw/7e09190b9e36a268844c4881ab8160c93262d8ff/halres-misc-archive-202609121210MT.zip

If these references change later, update this pinned-reference block first so
GPT and Codex remain aligned.

The shared local Flowise repositories under ~/RPA2/devneutral/flowise are the
provenance basis for the Flowise side of HalRes, not direct implementation
bases. Agents should not clone a second copy of the archived/current Flowise
repositories, should not install dependencies, and should not build those
upstream repositories unless explicitly requested. For normal HalRes v3 work,
inspect only the narrow documentation and source files needed for the three
analysis documents. For v4 custom flowisecpp work, use the archived
Flowise/FlowisePy provenance to extract requirements, design lessons, node and
workflow concepts, and failure/sunset cautions. Do not directly fork, port, or
mechanically translate the archived Flowise repository into the v4/v1 custom
flowisecpp build unless a later explicit decision changes this rule.

Agent-specific HalRes outputs remain under:

~/RPA2/devneutral/halres/gpt
~/RPA2/devneutral/halres/codex


for v4:
Each agent will start from the requirements, concepts, and cautions extracted
from the archived Flowise/FlowisePy provenance identified in v3 and consider
those in the context of v0 through v3 above.

The existing local Codex-side flowisecpp v0 build/source tree is available as a
comparison and cautionary/reference implementation, not as the default v4
baseline:

~/RPA2/codex/flowisecpp

Key flowisecpp design boundary for HalRes v4:

The custom flowisecpp v4/v1 track is not an attempt to duplicate the archived
Flowise/FlowisePy application's full range of functionality. The archived and
current Flowise repositories are provenance and design-reference inputs only.
The custom build target is a deliberately narrower local-native workflow
controller/editor/runtime with Ubuntu 24 as the OS baseline, bare-metal
deployment with no Docker, Docker-based services, Snap, or Docker-like services
that attempt to provide build configuration lock-in for Ubuntu applications or
enhance hardware/OS security through third-party confinement/sandboxing means.
The intended security baseline is normal Linux physical, login/rlogin, network,
and firewall protection only. The build should use local storage and local
model execution limited to llama.cpp-backed local GGUF models. Docker,
Docker-based services, Snap/Snapcraft-style packaging lock-in, Docker-like
Ubuntu application build lock-in services, third-party hardware/OS-security
confinement layers, cloud models, managed services, and broad Flowise
integration parity are out of scope unless a later explicit HalRes decision
changes that rule.

The current GPT intake/provenance snapshot for that existing local flowisecpp
tree is under:

~/RPA2/devneutral/halres/gpt/v4-intake/20260912_122915_MDT

Agents may inspect that local flowisecpp tree and snapshot to understand prior
Codex implementation choices, risks, and omissions. They should not assume that
tree resolves the HalRes v4 starting point. The v4 custom flowisecpp build
should be derived from the archived/current Flowise provenance findings and the
HalRes v0-v3 analysis products, not by direct inheritance from either the
archived Flowise GitHub repository or the existing Codex flowisecpp code. Any
reuse of existing Codex flowisecpp code, or any direct porting from archived
Flowise source, must be called out explicitly as a separate decision.

Then generate an analysis file of comments, criticisms and recommendations for a custom 
flowisecpp v1 build that will be agentic AI specific and constrained by the
local-native design boundary above. I.e. create a custom 
~/RPA2/<agent>/flowisecpp/v1 build folder
with the specific rules that it will not involve Python at all 
(all python code is to be translated into cpp and/or qt)
and custom-build the v3 products into v4 to run on bare iron Ubuntu 24, it will not involve Docker, any Docker-based services, Snap, any Docker-like services that attempt to provide build configuration lock-in for Ubuntu applications, or any third-party confinement/sandboxing service that attempts to enhance hardware/OS security outside normal Linux physical, login/rlogin, network, and firewall protection,
and it will use local llama.cpp-backed GGUF models rather than cloud or hosted model services.

For the time being we will leave any specific Docker-related, Docker-based, Snap/Snapcraft-style packaging lock-in, Docker-like build-lock-in, Docker-dependent, or third-party hardware/OS-security confinement features and services out of the custom v4 builds. Normal Linux physical security, login/rlogin policy, network configuration, and firewall protection remain acceptable host/OS administration concerns.
These will be custom prototype builds of flowisecpp, not production-targeted build. 

flowisecpp doesn't have to be ONLY cpp/qt, just use cpp/qt to replace the python code.
Any non-cpp/qt support must still preserve the Ubuntu 24,
no-Docker/no-Docker-based-services/no-Snap/no-Docker-like-build-lock-in-services/no-third-party-security-confinement-services,
local llama.cpp/GGUF-only scope boundary.
 
The goal of v4 will be to see if the v3 development process is sufficient to build custom v4 builds 

for v5: 
we will use the v3 custom test protocols to analyze the custom v4 builds
and comment appropriately based on the examples in the above versions. 

for v6:

each agent should design and build a custom test project (potentially ai<agent>chessplay v3r1b1)
and evaluate it using v3 and comment appropriately based on the examples in the above versions. 

for v6a:

Each agent should attempt to design a suitable "alternative algorithm" and
build for the pre-flowisecpp HalRes 2D state-space development steps. The
alternative algorithm/build should either not require a GUI, or otherwise can
run headless, while still producing outputs suitable for the later -flowisecpp
objectives and preserving the local-native Ubuntu 24/no-Docker/no-Snap/local
llama.cpp/GGUF-only scope boundaries described above where applicable.

for v6b:

Each agent should take the v6a alternative algorithm/build direction and add a
custom GUI of the agent's choice that runs on Ubuntu 24. The GUI toolkit may be
Qt6, Tcl/Tk, or another agent-selected Ubuntu 24-compatible toolkit, provided
the build still satisfies the -flowisecpp objectives and the local-native
scope boundaries described above.

for v6c:

Each agent should perform a cross-comparison of the GPT and Codex v6a and v6b
implementations. The comparison should evaluate the alternative algorithms,
headless/non-GUI behavior, GUI design choices, Ubuntu 24 compatibility,
fit with the pre-flowisecpp HalRes 2D state-space development steps, and
suitability as inputs to the later -flowisecpp objectives.


---

# GPT Recommended Project-Goals Addendum

Status: NONCANONICAL / GPT RECOMMENDATION ONLY

This section is not part of the user-defined canonical HalRes project goals
unless and until the user explicitly adopts some or all of it.

## Recommended algorithm-lineage handling

The original HalRes algorithm lineage is the v0/v1 development direction in
which English-language source material is transformed into an explicit 2D
state-space representation and reviewed as bounded decision/state transitions.

The essential original logic is:

- transform English-language material into a 2D state-space representation;
- identify explicit decision branches/state transitions;
- bind each decision to admissible evidence and an applicable rule;
- require a proposed next state to follow logically from the accepted prior
  state, the admissible evidence, and the applicable rule;
- preserve uncertainty, contradiction, or insufficient support as unresolved;
- preserve output pointers and scope so local decisions cannot silently alter
  larger process scope; and
- retain enough provenance to audit why each state and transition exists.

GPT previously formalized this direction as the Bounded State-Transition
Resolution Algorithm (BSTRA). The BSTRA name is a GPT-side formalization, not a
requirement of the canonical HalRes project.

## Recommended distinction between implementation changes and algorithm forks

A later HalRes implementation should identify itself as one of:

1. Original-lineage implementation
   - fundamentally preserves the original v0/v1 HalRes algorithm;
   - may change data structures, execution mechanics, performance strategy,
     headless/GUI design, or implementation language/toolkit.

2. Alternative implementation of the original HalRes algorithm
   - intentionally changes the implementation architecture while preserving the
     original decision/state-transition logic and intended result.

3. Alternative algorithm
   - materially changes the reasoning/state-space algorithm while still aiming
     to generate the required HalRes result;
   - must be documented and compared explicitly rather than silently replacing
     the original algorithm.

## Recommended prototype requirement

For each algorithm or implementation branch that is carried forward far enough
to be evaluated, produce:

- a working runnable prototype;
- source code;
- build and run instructions;
- representative input and output artifacts;
- algorithm/implementation documentation;
- logical/self-test results;
- provenance/evidence handling documentation;
- unresolved/failure behavior documentation; and
- a description of how downstream HalRes stages consume its output.

Documentation alone should not substitute for a runnable prototype when the
project stage is intended to test implementation behavior.

## Recommended v6a branch presentation

For v6a, GPT recommends treating the original-lineage branch and any genuinely
different algorithm branches as distinct experimental branches.

Suggested notation only:

- v6a-v0d : v6a implementation directly derived from the original v0 algorithm
- v6a-a1  : first materially different alternative algorithm
- v6a-a2  : second materially different alternative algorithm
- etc.

These labels are recommendations only and should not alter canonical project
versioning unless adopted by the user.

Each v6a branch should preferably run headless and should emit comparable
outputs suitable for later HalRes and -flowisecpp work.

## Recommended v6b branch presentation

For every v6a branch selected for continuation, add a GUI without removing the
headless path where practical.

Suggested lineage pairing only:

- v6a-v0d -> v6b-v0d
- v6a-a1  -> v6b-a1
- v6a-a2  -> v6b-a2

The GUI should not silently alter the algorithm or decision semantics.

## Recommended v6c comparison scope

Use working GPT and Codex artifacts wherever available.

Recommended comparison dimensions:

- cross-agent comparison of corresponding implementation lineages;
- cross-algorithm comparison when materially different algorithms exist;
- algorithmic assumptions and lineage;
- 2D state-space representation;
- bounded evidence and provenance behavior;
- decision/transition validity;
- unresolved/failure handling;
- headless/non-GUI behavior;
- GUI design and semantic consistency;
- Ubuntu 24 compatibility;
- runtime/resource behavior where measurable;
- fit with the pre-flowisecpp HalRes development objectives; and
- suitability as inputs to later -flowisecpp work.

## Recommended documentation rule

No material algorithm change should remain implicit.

Every downstream artifact should identify:

- the algorithm lineage that produced it;
- whether it is original-lineage, an alternative implementation, or a distinct
  alternative algorithm;
- the prototype/build version used;
- the input set used;
- and the downstream stage for which the output is intended.

If multiple viable algorithm branches exist, preserve them as distinct branches
long enough to compare them explicitly before deciding whether to converge,
retain multiple approaches, or discontinue one.
